/*
 * Copyright (c) 2023, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.c =============
 *  Configured MSPM0 DriverLib module definitions
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G150X
 *  by the SysConfig tool.
 */

#include "ti_msp_dl_config.h"

DL_TimerA_backupConfig gSMPL_CLKBackup;
DL_TimerA_backupConfig gSESSION_ZEROED_CLOCKBackup;
DL_SPI_backupConfig gSPI_1_USDBackup;
DL_SPI_backupConfig gSPI_0_INTANBackup;

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform any initialization needed before using any board APIs
 */
SYSCONFIG_WEAK void SYSCFG_DL_init(void)
{
    SYSCFG_DL_initPower();
    SYSCFG_DL_GPIO_init();
    /* Module-Specific Initializations*/
    SYSCFG_DL_SYSCTL_init();
    SYSCFG_DL_SMPL_CLK_init();
    SYSCFG_DL_SESSION_ZEROED_CLOCK_init();
    SYSCFG_DL_SAMPLE_TIME_REFERENCE_init();
    SYSCFG_DL_SPI_1_USD_init();
    SYSCFG_DL_SPI_0_INTAN_init();
    SYSCFG_DL_DMA_init();
    /* Ensure backup structures have no valid state */
	gSMPL_CLKBackup.backupRdy 	= false;
	gSESSION_ZEROED_CLOCKBackup.backupRdy 	= false;
	gSPI_1_USDBackup.backupRdy 	= false;
	gSPI_0_INTANBackup.backupRdy 	= false;

}
/*
 * User should take care to save and restore register configuration in application.
 * See Retention Configuration section for more details.
 */
SYSCONFIG_WEAK bool SYSCFG_DL_saveConfiguration(void)
{
    bool retStatus = true;

	retStatus &= DL_TimerA_saveConfiguration(SMPL_CLK_INST, &gSMPL_CLKBackup);
	retStatus &= DL_TimerA_saveConfiguration(SESSION_ZEROED_CLOCK_INST, &gSESSION_ZEROED_CLOCKBackup);
	retStatus &= DL_SPI_saveConfiguration(SPI_1_USD_INST, &gSPI_1_USDBackup);
	retStatus &= DL_SPI_saveConfiguration(SPI_0_INTAN_INST, &gSPI_0_INTANBackup);

    return retStatus;
}


SYSCONFIG_WEAK bool SYSCFG_DL_restoreConfiguration(void)
{
    bool retStatus = true;

	retStatus &= DL_TimerA_restoreConfiguration(SMPL_CLK_INST, &gSMPL_CLKBackup, false);
	retStatus &= DL_TimerA_restoreConfiguration(SESSION_ZEROED_CLOCK_INST, &gSESSION_ZEROED_CLOCKBackup, false);
	retStatus &= DL_SPI_restoreConfiguration(SPI_1_USD_INST, &gSPI_1_USDBackup);
	retStatus &= DL_SPI_restoreConfiguration(SPI_0_INTAN_INST, &gSPI_0_INTANBackup);

    return retStatus;
}

SYSCONFIG_WEAK void SYSCFG_DL_initPower(void)
{
    DL_GPIO_reset(GPIOA);
    DL_TimerA_reset(SMPL_CLK_INST);
    DL_TimerA_reset(SESSION_ZEROED_CLOCK_INST);
    DL_TimerG_reset(SAMPLE_TIME_REFERENCE_INST);
    DL_SPI_reset(SPI_1_USD_INST);
    DL_SPI_reset(SPI_0_INTAN_INST);


    DL_GPIO_enablePower(GPIOA);
    DL_TimerA_enablePower(SMPL_CLK_INST);
    DL_TimerA_enablePower(SESSION_ZEROED_CLOCK_INST);
    DL_TimerG_enablePower(SAMPLE_TIME_REFERENCE_INST);
    DL_SPI_enablePower(SPI_1_USD_INST);
    DL_SPI_enablePower(SPI_0_INTAN_INST);

    delay_cycles(POWER_STARTUP_DELAY);
}

SYSCONFIG_WEAK void SYSCFG_DL_GPIO_init(void)
{

    
	DL_GPIO_initPeripheralOutputFunction(
		 GPIO_SPI_1_USD_IOMUX_SCLK, GPIO_SPI_1_USD_IOMUX_SCLK_FUNC);
	DL_GPIO_initPeripheralOutputFunction(
		 GPIO_SPI_1_USD_IOMUX_PICO, GPIO_SPI_1_USD_IOMUX_PICO_FUNC);
	DL_GPIO_initPeripheralInputFunctionFeatures(
		 GPIO_SPI_1_USD_IOMUX_POCI, GPIO_SPI_1_USD_IOMUX_POCI_FUNC,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_NONE,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_SPI_0_INTAN_IOMUX_SCLK, GPIO_SPI_0_INTAN_IOMUX_SCLK_FUNC);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_SPI_0_INTAN_IOMUX_PICO, GPIO_SPI_0_INTAN_IOMUX_PICO_FUNC);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_SPI_0_INTAN_IOMUX_POCI, GPIO_SPI_0_INTAN_IOMUX_POCI_FUNC);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_SPI_0_INTAN_IOMUX_CS0, GPIO_SPI_0_INTAN_IOMUX_CS0_FUNC);

    DL_GPIO_initDigitalOutput(SD_CS_SD_CS_PIN_IOMUX);

    DL_GPIO_initDigitalInputFeatures(RECORD_BUTTON_RECORD_BUTTON_PIN_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_NONE,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalOutput(RECORD__START_LED_RECORD_START_LED_PIN_IOMUX);

    DL_GPIO_initDigitalInputFeatures(GPIO_PULLDOWN_GROUP_PA1_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_DOWN,
		 DL_GPIO_HYSTERESIS_ENABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalInputFeatures(GPIO_PULLDOWN_GROUP_PA7_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_DOWN,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalInputFeatures(GPIO_PULLDOWN_GROUP_PA11_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_DOWN,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalOutput(GPIO_PULLDOWN_GROUP_PA13_IOMUX);

    DL_GPIO_initDigitalInputFeatures(GPIO_PULLDOWN_GROUP_PA14_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_DOWN,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalOutput(GPIO_PULLDOWN_GROUP_PA15_IOMUX);

    DL_GPIO_initDigitalInputFeatures(GPIO_PULLDOWN_GROUP_PA22_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_DOWN,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_initDigitalInputFeatures(GPIO_PULLDOWN_GROUP_PA25_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_DOWN,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_clearPins(GPIOA, RECORD__START_LED_RECORD_START_LED_PIN_PIN |
		GPIO_PULLDOWN_GROUP_PA13_PIN |
		GPIO_PULLDOWN_GROUP_PA15_PIN);
    DL_GPIO_setPins(GPIOA, SD_CS_SD_CS_PIN_PIN);
    DL_GPIO_enableOutput(GPIOA, SD_CS_SD_CS_PIN_PIN |
		RECORD__START_LED_RECORD_START_LED_PIN_PIN |
		GPIO_PULLDOWN_GROUP_PA13_PIN |
		GPIO_PULLDOWN_GROUP_PA15_PIN);
    DL_GPIO_setLowerPinsPolarity(GPIOA, DL_GPIO_PIN_3_EDGE_FALL);
    DL_GPIO_clearInterruptStatus(GPIOA, RECORD_BUTTON_RECORD_BUTTON_PIN_PIN);
    DL_GPIO_enableInterrupt(GPIOA, RECORD_BUTTON_RECORD_BUTTON_PIN_PIN);

}



/*
   Performs SYSOSC trim by adjusting values of RESCOARE and RFINE and using the FCC
   module to read back the frequency until the target value is hit.
*/
SYSCONFIG_WEAK void DL_SYSCFG_SYSCTL_SYSOSC_USERTRIM(uint8_t SYSCTL_SYSOSCTRIMUSER_FREQ_SYSOSC)
{
    float freqTarget = SYSCTL_SYSOSCTRIMUSER_FREQ_SYSOSC == SYSCTL_SYSOSCTRIMUSER_FREQ_SYSOSC16M ? 16000 : 24000;
    float freqStart = 0, freqMid = 0, freqEnd = 0, freqBest = 0;
    float errorStart = 1, errorEnd = 1;
    bool perfectFlag = 0;

    uint32_t FCC_period;
    uint32_t countStart, countEnd, countBest;
    uint32_t startOSCTRIM, endOSCTRIM, bestOSCTRIM;

    DL_SYSCTL_startFCC();
    while (false == DL_SYSCTL_isFCCDone());
    uint32_t fccPeriodCalibration = ((SYSCTL->SOCLOCK.GENCLKCFG & SYSCTL_GENCLKCFG_FCCTRIGCNT_MASK) >> SYSCTL_GENCLKCFG_FCCTRIGCNT_OFS) + 1;
    uint32_t fccCountCalibration = (SYSCTL->SOCLOCK.FCC) & SYSCTL_FCC_DATA_MASK;
    float freqMidCalibration = fccCountCalibration / 32000.0;
    float freqTriggerCalibration = fccPeriodCalibration / freqMidCalibration;

    uint32_t grayCodeRESFINE[16] = {0x00,0x01,0x03,0x02,0x06,0x07,0x05,0x04,0x0C,0x0D,0x0F,0x0E,0x0A,0x0B,0x09,0x08};
    uint32_t startIndexRESFINE = 0;
    uint32_t startRESFINEValue = 0x000C0000;
    uint32_t endIndexRESFINE = 0x0F;
    uint32_t setRESFINE = 0;
    uint32_t startRESCOARE = 0x00001F00;
    uint32_t endRESCOARE = 0x00003F00;
    uint32_t setRESCOARE = 0;

    DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_BASE);
    DL_Common_updateReg(&SYSCTL->SOCLOCK.SYSOSCTRIMUSER, startRESCOARE, SYSCTL_SYSOSCTRIMUSER_RESCOARSE_MASK);
    DL_Common_updateReg(&SYSCTL->SOCLOCK.SYSOSCTRIMUSER, startRESFINEValue, SYSCTL_SYSOSCTRIMUSER_RESFINE_MASK);
    DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_USERTRIM);
    delay_cycles (10000);

    uint32_t startSYSTRIM = (startRESCOARE >> 4) + startIndexRESFINE;
    uint32_t endSYSTRIM = (endRESCOARE >> 4) + endIndexRESFINE;
    uint32_t midSYSTRIM;

    while(endSYSTRIM > startSYSTRIM + 1) {
        midSYSTRIM = (startSYSTRIM + endSYSTRIM) / 2;
        setRESFINE = grayCodeRESFINE [midSYSTRIM & 0x0000000F] << 16;
        setRESCOARE = (midSYSTRIM & 0x00000FF0) << 4;

        DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_BASE);
        DL_Common_updateReg(&SYSCTL->SOCLOCK.SYSOSCTRIMUSER, SYSCTL_SYSOSCTRIMUSER_FREQ_SYSOSC, SYSCTL_SYSOSCTRIMUSER_FREQ_MASK);
        DL_Common_updateReg(&SYSCTL->SOCLOCK.SYSOSCTRIMUSER, setRESCOARE, SYSCTL_SYSOSCTRIMUSER_RESCOARSE_MASK);
        DL_Common_updateReg(&SYSCTL->SOCLOCK.SYSOSCTRIMUSER, setRESFINE, SYSCTL_SYSOSCTRIMUSER_RESFINE_MASK);
        DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_USERTRIM);
        delay_cycles (10000);
        DL_SYSCTL_startFCC();
        while (false == DL_SYSCTL_isFCCDone());
        bestOSCTRIM = SYSCTL->SOCLOCK.SYSOSCTRIMUSER;
        FCC_period = (((SYSCTL->SOCLOCK.GENCLKCFG) & SYSCTL_GENCLKCFG_FCCTRIGCNT_MASK) >> SYSCTL_GENCLKCFG_FCCTRIGCNT_OFS) + 1;
        countBest = (SYSCTL->SOCLOCK.FCC) & SYSCTL_FCC_DATA_MASK;
        freqMid = FCC_period / freqTriggerCalibration;
        freqBest = countBest / freqMid;
        if (freqBest > freqTarget) {
           startSYSTRIM = midSYSTRIM;
           freqStart = freqBest;
           errorStart = (freqBest - freqTarget ) / freqTarget * 100;
           countStart =  countBest;
           startOSCTRIM = bestOSCTRIM;
        }
        if (freqBest < freqTarget) {
           endSYSTRIM = midSYSTRIM;
           errorEnd = (freqTarget - freqBest) / freqTarget * 100;
           freqEnd = freqBest;
           countEnd = countBest;
           endOSCTRIM = bestOSCTRIM;
        }
        if (freqBest == freqTarget) {
           perfectFlag = 1;
           break;
        }
    }

    if (perfectFlag != 1) {
        if (errorEnd <= errorStart) {
            freqBest =  freqEnd;
            countBest = countEnd;
            bestOSCTRIM = endOSCTRIM;
        }
        else {
            freqBest =  freqStart;
            countBest = countStart;
            bestOSCTRIM = startOSCTRIM;
        }
    }

    DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_BASE);
    SYSCTL->SOCLOCK.SYSOSCTRIMUSER = bestOSCTRIM;
    DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_USERTRIM);
}

SYSCONFIG_WEAK void SYSCFG_DL_SYSCTL_init(void)
{

	//Low Power Mode is configured to be SLEEP0
    DL_SYSCTL_setBORThreshold(DL_SYSCTL_BOR_THRESHOLD_LEVEL_0);

    
	DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_BASE);

}



/*
 * Timer clock configuration to be sourced by BUSCLK /  (32000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   32000000 Hz = 32000000 Hz / (1 * (0 + 1))
 */
static const DL_TimerA_ClockConfig gSMPL_CLKClockConfig = {
    .clockSel    = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
    .prescale    = 0U,
};

/*
 * Timer load value (where the counter starts from) is calculated as (timerPeriod * timerClockFreq) - 1
 * SMPL_CLK_INST_LOAD_VALUE = (.05ms * 32000000 Hz) - 1
 */
static const DL_TimerA_TimerConfig gSMPL_CLKTimerConfig = {
    .period     = SMPL_CLK_INST_LOAD_VALUE,
    .timerMode  = DL_TIMER_TIMER_MODE_PERIODIC,
    .startTimer = DL_TIMER_STOP,
};

SYSCONFIG_WEAK void SYSCFG_DL_SMPL_CLK_init(void) {

    DL_TimerA_setClockConfig(SMPL_CLK_INST,
        (DL_TimerA_ClockConfig *) &gSMPL_CLKClockConfig);

    DL_TimerA_initTimerMode(SMPL_CLK_INST,
        (DL_TimerA_TimerConfig *) &gSMPL_CLKTimerConfig);
    DL_TimerA_enableInterrupt(SMPL_CLK_INST , DL_TIMERA_INTERRUPT_ZERO_EVENT);
	NVIC_SetPriority(SMPL_CLK_INST_INT_IRQN, 1);
    DL_TimerA_enableClock(SMPL_CLK_INST);





}

/*
 * Timer clock configuration to be sourced by BUSCLK /  (32000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   1000000 Hz = 32000000 Hz / (1 * (31 + 1))
 */
static const DL_TimerA_ClockConfig gSESSION_ZEROED_CLOCKClockConfig = {
    .clockSel    = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
    .prescale    = 31U,
};

/*
 * Timer load value (where the counter starts from) is calculated as (timerPeriod * timerClockFreq) - 1
 * SESSION_ZEROED_CLOCK_INST_LOAD_VALUE = (.06553 * 1000000 Hz) - 1
 */
static const DL_TimerA_TimerConfig gSESSION_ZEROED_CLOCKTimerConfig = {
    .period     = SESSION_ZEROED_CLOCK_INST_LOAD_VALUE,
    .timerMode  = DL_TIMER_TIMER_MODE_PERIODIC_UP,
    .startTimer = DL_TIMER_STOP,
};

SYSCONFIG_WEAK void SYSCFG_DL_SESSION_ZEROED_CLOCK_init(void) {

    DL_TimerA_setClockConfig(SESSION_ZEROED_CLOCK_INST,
        (DL_TimerA_ClockConfig *) &gSESSION_ZEROED_CLOCKClockConfig);

    DL_TimerA_initTimerMode(SESSION_ZEROED_CLOCK_INST,
        (DL_TimerA_TimerConfig *) &gSESSION_ZEROED_CLOCKTimerConfig);
    DL_TimerA_enableClock(SESSION_ZEROED_CLOCK_INST);





}

/*
 * Timer clock configuration to be sourced by BUSCLK /  (32000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   1032258.0645161291 Hz = 32000000 Hz / (1 * (30 + 1))
 */
static const DL_TimerG_ClockConfig gSAMPLE_TIME_REFERENCEClockConfig = {
    .clockSel    = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
    .prescale    = 30U,
};

/*
 * Timer load value (where the counter starts from) is calculated as (timerPeriod * timerClockFreq) - 1
 * SAMPLE_TIME_REFERENCE_INST_LOAD_VALUE = (60 ms * 1032258.0645161291 Hz) - 1
 */
static const DL_TimerG_TimerConfig gSAMPLE_TIME_REFERENCETimerConfig = {
    .period     = SAMPLE_TIME_REFERENCE_INST_LOAD_VALUE,
    .timerMode  = DL_TIMER_TIMER_MODE_PERIODIC_UP,
    .startTimer = DL_TIMER_START,
};

SYSCONFIG_WEAK void SYSCFG_DL_SAMPLE_TIME_REFERENCE_init(void) {

    DL_TimerG_setClockConfig(SAMPLE_TIME_REFERENCE_INST,
        (DL_TimerG_ClockConfig *) &gSAMPLE_TIME_REFERENCEClockConfig);

    DL_TimerG_initTimerMode(SAMPLE_TIME_REFERENCE_INST,
        (DL_TimerG_TimerConfig *) &gSAMPLE_TIME_REFERENCETimerConfig);
    DL_TimerG_enableClock(SAMPLE_TIME_REFERENCE_INST);





}


static const DL_SPI_Config gSPI_1_USD_config = {
    .mode        = DL_SPI_MODE_CONTROLLER,
    .frameFormat = DL_SPI_FRAME_FORMAT_MOTO3_POL0_PHA0,
    .parity      = DL_SPI_PARITY_NONE,
    .dataSize    = DL_SPI_DATA_SIZE_8,
    .bitOrder    = DL_SPI_BIT_ORDER_MSB_FIRST,
};

static const DL_SPI_ClockConfig gSPI_1_USD_clockConfig = {
    .clockSel    = DL_SPI_CLOCK_BUSCLK,
    .divideRatio = DL_SPI_CLOCK_DIVIDE_RATIO_1
};

SYSCONFIG_WEAK void SYSCFG_DL_SPI_1_USD_init(void) {
    DL_SPI_setClockConfig(SPI_1_USD_INST, (DL_SPI_ClockConfig *) &gSPI_1_USD_clockConfig);

    DL_SPI_init(SPI_1_USD_INST, (DL_SPI_Config *) &gSPI_1_USD_config);

    /* Configure Controller mode */
    /*
     * Set the bit rate clock divider to generate the serial output clock
     *     outputBitRate = (spiInputClock) / ((1 + SCR) * 2)
     *     400000 = (32000000)/((1 + 39) * 2)
     */
    DL_SPI_setBitRateSerialClockDivider(SPI_1_USD_INST, 39);

    /* Enable SPI TX interrupt as a trigger for DMA */
    DL_SPI_enableDMATransmitEvent(SPI_1_USD_INST);

    /* Enable SPI RX interrupt as a trigger for DMA */
    DL_SPI_enableDMAReceiveEvent(SPI_1_USD_INST, DL_SPI_DMA_INTERRUPT_RX);
    /* Set RX and TX FIFO threshold levels */
    DL_SPI_setFIFOThreshold(SPI_1_USD_INST, DL_SPI_RX_FIFO_LEVEL_ONE_FRAME, DL_SPI_TX_FIFO_LEVEL_ONE_FRAME);

    /* Enable module */
    DL_SPI_enable(SPI_1_USD_INST);
}
static const DL_SPI_Config gSPI_0_INTAN_config = {
    .mode        = DL_SPI_MODE_CONTROLLER,
    .frameFormat = DL_SPI_FRAME_FORMAT_MOTO4_POL0_PHA0,
    .parity      = DL_SPI_PARITY_NONE,
    .dataSize    = DL_SPI_DATA_SIZE_16,
    .bitOrder    = DL_SPI_BIT_ORDER_MSB_FIRST,
    .chipSelectPin = DL_SPI_CHIP_SELECT_0,
};

static const DL_SPI_ClockConfig gSPI_0_INTAN_clockConfig = {
    .clockSel    = DL_SPI_CLOCK_BUSCLK,
    .divideRatio = DL_SPI_CLOCK_DIVIDE_RATIO_1
};

SYSCONFIG_WEAK void SYSCFG_DL_SPI_0_INTAN_init(void) {
    DL_SPI_setClockConfig(SPI_0_INTAN_INST, (DL_SPI_ClockConfig *) &gSPI_0_INTAN_clockConfig);

    DL_SPI_init(SPI_0_INTAN_INST, (DL_SPI_Config *) &gSPI_0_INTAN_config);

    /* Configure Controller mode */
    /*
     * Set the bit rate clock divider to generate the serial output clock
     *     outputBitRate = (spiInputClock) / ((1 + SCR) * 2)
     *     5333333.33 = (32000000)/((1 + 2) * 2)
     */
    DL_SPI_setBitRateSerialClockDivider(SPI_0_INTAN_INST, 2);

    /* Enable SPI TX interrupt as a trigger for DMA */
    DL_SPI_enableDMATransmitEvent(SPI_0_INTAN_INST);

    /* Enable SPI RX interrupt as a trigger for DMA */
    DL_SPI_enableDMAReceiveEvent(SPI_0_INTAN_INST, DL_SPI_DMA_INTERRUPT_RX);
    /* Set RX and TX FIFO threshold levels */
    DL_SPI_setFIFOThreshold(SPI_0_INTAN_INST, DL_SPI_RX_FIFO_LEVEL_ONE_FRAME, DL_SPI_TX_FIFO_LEVEL_ONE_FRAME);

    /* Enable module */
    DL_SPI_enable(SPI_0_INTAN_INST);
}

static const DL_DMA_Config gUSD_RX_DMA_CH3Config = {
    .transferMode   = DL_DMA_SINGLE_TRANSFER_MODE,
    .extendedMode   = DL_DMA_NORMAL_MODE,
    .destIncrement  = DL_DMA_ADDR_UNCHANGED,
    .srcIncrement   = DL_DMA_ADDR_UNCHANGED,
    .destWidth      = DL_DMA_WIDTH_BYTE,
    .srcWidth       = DL_DMA_WIDTH_BYTE,
    .trigger        = SPI_1_USD_INST_DMA_TRIGGER_0,
    .triggerType    = DL_DMA_TRIGGER_TYPE_EXTERNAL,
};

SYSCONFIG_WEAK void SYSCFG_DL_USD_RX_DMA_CH3_init(void)
{
    DL_DMA_setTransferSize(DMA, USD_RX_DMA_CH3_CHAN_ID, 512);
    DL_DMA_initChannel(DMA, USD_RX_DMA_CH3_CHAN_ID , (DL_DMA_Config *) &gUSD_RX_DMA_CH3Config);
}
static const DL_DMA_Config gUSD_TX_DMA_CH2Config = {
    .transferMode   = DL_DMA_SINGLE_TRANSFER_MODE,
    .extendedMode   = DL_DMA_NORMAL_MODE,
    .destIncrement  = DL_DMA_ADDR_UNCHANGED,
    .srcIncrement   = DL_DMA_ADDR_INCREMENT,
    .destWidth      = DL_DMA_WIDTH_BYTE,
    .srcWidth       = DL_DMA_WIDTH_BYTE,
    .trigger        = SPI_1_USD_INST_DMA_TRIGGER_1,
    .triggerType    = DL_DMA_TRIGGER_TYPE_EXTERNAL,
};

SYSCONFIG_WEAK void SYSCFG_DL_USD_TX_DMA_CH2_init(void)
{
    DL_DMA_setTransferSize(DMA, USD_TX_DMA_CH2_CHAN_ID, 1);
    DL_DMA_initChannel(DMA, USD_TX_DMA_CH2_CHAN_ID , (DL_DMA_Config *) &gUSD_TX_DMA_CH2Config);
}
static const DL_DMA_Config gINTAN_RX_DMA_CH1Config = {
    .transferMode   = DL_DMA_SINGLE_TRANSFER_MODE,
    .extendedMode   = DL_DMA_NORMAL_MODE,
    .destIncrement  = DL_DMA_ADDR_INCREMENT,
    .srcIncrement   = DL_DMA_ADDR_UNCHANGED,
    .destWidth      = DL_DMA_WIDTH_HALF_WORD,
    .srcWidth       = DL_DMA_WIDTH_HALF_WORD,
    .trigger        = SPI_0_INTAN_INST_DMA_TRIGGER_0,
    .triggerType    = DL_DMA_TRIGGER_TYPE_EXTERNAL,
};

SYSCONFIG_WEAK void SYSCFG_DL_INTAN_RX_DMA_CH1_init(void)
{
    DL_DMA_clearInterruptStatus(DMA, DL_DMA_INTERRUPT_CHANNEL1);
    DL_DMA_enableInterrupt(DMA, DL_DMA_INTERRUPT_CHANNEL1);
    DL_DMA_initChannel(DMA, INTAN_RX_DMA_CH1_CHAN_ID , (DL_DMA_Config *) &gINTAN_RX_DMA_CH1Config);
}
static const DL_DMA_Config gINTAN_TX_DMA_CH0Config = {
    .transferMode   = DL_DMA_SINGLE_TRANSFER_MODE,
    .extendedMode   = DL_DMA_NORMAL_MODE,
    .destIncrement  = DL_DMA_ADDR_UNCHANGED,
    .srcIncrement   = DL_DMA_ADDR_INCREMENT,
    .destWidth      = DL_DMA_WIDTH_HALF_WORD,
    .srcWidth       = DL_DMA_WIDTH_HALF_WORD,
    .trigger        = SPI_0_INTAN_INST_DMA_TRIGGER_1,
    .triggerType    = DL_DMA_TRIGGER_TYPE_EXTERNAL,
};

SYSCONFIG_WEAK void SYSCFG_DL_INTAN_TX_DMA_CH0_init(void)
{
    DL_DMA_initChannel(DMA, INTAN_TX_DMA_CH0_CHAN_ID , (DL_DMA_Config *) &gINTAN_TX_DMA_CH0Config);
}
SYSCONFIG_WEAK void SYSCFG_DL_DMA_init(void){
    SYSCFG_DL_USD_RX_DMA_CH3_init();
    SYSCFG_DL_USD_TX_DMA_CH2_init();
    SYSCFG_DL_INTAN_RX_DMA_CH1_init();
    SYSCFG_DL_INTAN_TX_DMA_CH0_init();
}


