# FIXED

ffunicode.o: ../ffunicode.c \
 C:/Users/Anemed_Laptop_01/workspace_ccstheia/logger2\ 3\ big\ buffers\ 1507/ff.h \
 C:/Users/Anemed_Laptop_01/workspace_ccstheia/logger2\ 3\ big\ buffers\ 1507/ffconf.h

C:/Users/Anemed_Laptop_01/workspace_ccstheia/logger2\ 3\ big\ buffers\ 1507/ff.h:

C:/Users/Anemed_Laptop_01/workspace_ccstheia/logger2\ 3\ big\ buffers\ 1507/ffconf.h:
