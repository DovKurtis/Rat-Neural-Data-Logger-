/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G150X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G150X
#define CONFIG_MSPM0G1507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     32000000



/* Defines for SMPL_CLK */
#define SMPL_CLK_INST                                                    (TIMA1)
#define SMPL_CLK_INST_IRQHandler                                TIMA1_IRQHandler
#define SMPL_CLK_INST_INT_IRQN                                  (TIMA1_INT_IRQn)
#define SMPL_CLK_INST_LOAD_VALUE                                         (1599U)
/* Defines for SESSION_ZEROED_CLOCK */
#define SESSION_ZEROED_CLOCK_INST                                        (TIMA0)
#define SESSION_ZEROED_CLOCK_INST_IRQHandler                        TIMA0_IRQHandler
#define SESSION_ZEROED_CLOCK_INST_INT_IRQN                        (TIMA0_INT_IRQn)
#define SESSION_ZEROED_CLOCK_INST_LOAD_VALUE                                (65529U)
/* Defines for SAMPLE_TIME_REFERENCE */
#define SAMPLE_TIME_REFERENCE_INST                                       (TIMG0)
#define SAMPLE_TIME_REFERENCE_INST_IRQHandler                        TIMG0_IRQHandler
#define SAMPLE_TIME_REFERENCE_INST_INT_IRQN                        (TIMG0_INT_IRQn)
#define SAMPLE_TIME_REFERENCE_INST_LOAD_VALUE                                (61934U)



/* Defines for SPI_1_USD */
#define SPI_1_USD_INST                                                     SPI1
#define SPI_1_USD_INST_IRQHandler                               SPI1_IRQHandler
#define SPI_1_USD_INST_INT_IRQN                                   SPI1_INT_IRQn
#define GPIO_SPI_1_USD_PICO_PORT                                          GPIOA
#define GPIO_SPI_1_USD_PICO_PIN                                  DL_GPIO_PIN_18
#define GPIO_SPI_1_USD_IOMUX_PICO                               (IOMUX_PINCM40)
#define GPIO_SPI_1_USD_IOMUX_PICO_FUNC               IOMUX_PINCM40_PF_SPI1_PICO
#define GPIO_SPI_1_USD_POCI_PORT                                          GPIOA
#define GPIO_SPI_1_USD_POCI_PIN                                  DL_GPIO_PIN_16
#define GPIO_SPI_1_USD_IOMUX_POCI                               (IOMUX_PINCM38)
#define GPIO_SPI_1_USD_IOMUX_POCI_FUNC               IOMUX_PINCM38_PF_SPI1_POCI
/* GPIO configuration for SPI_1_USD */
#define GPIO_SPI_1_USD_SCLK_PORT                                          GPIOA
#define GPIO_SPI_1_USD_SCLK_PIN                                  DL_GPIO_PIN_17
#define GPIO_SPI_1_USD_IOMUX_SCLK                               (IOMUX_PINCM39)
#define GPIO_SPI_1_USD_IOMUX_SCLK_FUNC               IOMUX_PINCM39_PF_SPI1_SCLK
/* Defines for SPI_0_INTAN */
#define SPI_0_INTAN_INST                                                   SPI0
#define SPI_0_INTAN_INST_IRQHandler                             SPI0_IRQHandler
#define SPI_0_INTAN_INST_INT_IRQN                                 SPI0_INT_IRQn
#define GPIO_SPI_0_INTAN_PICO_PORT                                        GPIOA
#define GPIO_SPI_0_INTAN_PICO_PIN                                 DL_GPIO_PIN_9
#define GPIO_SPI_0_INTAN_IOMUX_PICO                             (IOMUX_PINCM20)
#define GPIO_SPI_0_INTAN_IOMUX_PICO_FUNC             IOMUX_PINCM20_PF_SPI0_PICO
#define GPIO_SPI_0_INTAN_POCI_PORT                                        GPIOA
#define GPIO_SPI_0_INTAN_POCI_PIN                                DL_GPIO_PIN_10
#define GPIO_SPI_0_INTAN_IOMUX_POCI                             (IOMUX_PINCM21)
#define GPIO_SPI_0_INTAN_IOMUX_POCI_FUNC             IOMUX_PINCM21_PF_SPI0_POCI
/* GPIO configuration for SPI_0_INTAN */
#define GPIO_SPI_0_INTAN_SCLK_PORT                                        GPIOA
#define GPIO_SPI_0_INTAN_SCLK_PIN                                DL_GPIO_PIN_12
#define GPIO_SPI_0_INTAN_IOMUX_SCLK                             (IOMUX_PINCM34)
#define GPIO_SPI_0_INTAN_IOMUX_SCLK_FUNC             IOMUX_PINCM34_PF_SPI0_SCLK
#define GPIO_SPI_0_INTAN_CS0_PORT                                         GPIOA
#define GPIO_SPI_0_INTAN_CS0_PIN                                  DL_GPIO_PIN_8
#define GPIO_SPI_0_INTAN_IOMUX_CS0                              (IOMUX_PINCM19)
#define GPIO_SPI_0_INTAN_IOMUX_CS0_FUNC               IOMUX_PINCM19_PF_SPI0_CS0



/* Defines for USD_RX_DMA_CH3 */
#define USD_RX_DMA_CH3_CHAN_ID                                               (3)
#define SPI_1_USD_INST_DMA_TRIGGER_0                          (DMA_SPI1_RX_TRIG)
/* Defines for USD_TX_DMA_CH2 */
#define USD_TX_DMA_CH2_CHAN_ID                                               (2)
#define SPI_1_USD_INST_DMA_TRIGGER_1                          (DMA_SPI1_TX_TRIG)
/* Defines for INTAN_RX_DMA_CH1 */
#define INTAN_RX_DMA_CH1_CHAN_ID                                             (1)
#define SPI_0_INTAN_INST_DMA_TRIGGER_0                        (DMA_SPI0_RX_TRIG)
/* Defines for INTAN_TX_DMA_CH0 */
#define INTAN_TX_DMA_CH0_CHAN_ID                                             (0)
#define SPI_0_INTAN_INST_DMA_TRIGGER_1                        (DMA_SPI0_TX_TRIG)


/* Port definition for Pin Group SD_CS */
#define SD_CS_PORT                                                       (GPIOA)

/* Defines for SD_CS_PIN: GPIOA.27 with pinCMx 60 on package pin 31 */
#define SD_CS_SD_CS_PIN_PIN                                     (DL_GPIO_PIN_27)
#define SD_CS_SD_CS_PIN_IOMUX                                    (IOMUX_PINCM60)
/* Port definition for Pin Group RECORD_BUTTON */
#define RECORD_BUTTON_PORT                                               (GPIOA)

/* Defines for RECORD_BUTTON_PIN: GPIOA.3 with pinCMx 8 on package pin 7 */
// pins affected by this interrupt request:["RECORD_BUTTON_PIN"]
#define RECORD_BUTTON_INT_IRQN                                  (GPIOA_INT_IRQn)
#define RECORD_BUTTON_INT_IIDX                  (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define RECORD_BUTTON_RECORD_BUTTON_PIN_IIDX                 (DL_GPIO_IIDX_DIO3)
#define RECORD_BUTTON_RECORD_BUTTON_PIN_PIN                      (DL_GPIO_PIN_3)
#define RECORD_BUTTON_RECORD_BUTTON_PIN_IOMUX                     (IOMUX_PINCM8)
/* Port definition for Pin Group RECORD__START_LED */
#define RECORD__START_LED_PORT                                           (GPIOA)

/* Defines for RECORD_START_LED_PIN: GPIOA.0 with pinCMx 1 on package pin 1 */
#define RECORD__START_LED_RECORD_START_LED_PIN_PIN               (DL_GPIO_PIN_0)
#define RECORD__START_LED_RECORD_START_LED_PIN_IOMUX              (IOMUX_PINCM1)
/* Port definition for Pin Group GPIO_PULLDOWN_GROUP */
#define GPIO_PULLDOWN_GROUP_PORT                                         (GPIOA)

/* Defines for PA1: GPIOA.1 with pinCMx 2 on package pin 2 */
#define GPIO_PULLDOWN_GROUP_PA1_PIN                              (DL_GPIO_PIN_1)
#define GPIO_PULLDOWN_GROUP_PA1_IOMUX                             (IOMUX_PINCM2)
/* Defines for PA7: GPIOA.7 with pinCMx 14 on package pin 11 */
#define GPIO_PULLDOWN_GROUP_PA7_PIN                              (DL_GPIO_PIN_7)
#define GPIO_PULLDOWN_GROUP_PA7_IOMUX                            (IOMUX_PINCM14)
/* Defines for PA11: GPIOA.11 with pinCMx 22 on package pin 15 */
#define GPIO_PULLDOWN_GROUP_PA11_PIN                            (DL_GPIO_PIN_11)
#define GPIO_PULLDOWN_GROUP_PA11_IOMUX                           (IOMUX_PINCM22)
/* Defines for PA13: GPIOA.13 with pinCMx 35 on package pin 17 */
#define GPIO_PULLDOWN_GROUP_PA13_PIN                            (DL_GPIO_PIN_13)
#define GPIO_PULLDOWN_GROUP_PA13_IOMUX                           (IOMUX_PINCM35)
/* Defines for PA14: GPIOA.14 with pinCMx 36 on package pin 18 */
#define GPIO_PULLDOWN_GROUP_PA14_PIN                            (DL_GPIO_PIN_14)
#define GPIO_PULLDOWN_GROUP_PA14_IOMUX                           (IOMUX_PINCM36)
/* Defines for PA15: GPIOA.15 with pinCMx 37 on package pin 19 */
#define GPIO_PULLDOWN_GROUP_PA15_PIN                            (DL_GPIO_PIN_15)
#define GPIO_PULLDOWN_GROUP_PA15_IOMUX                           (IOMUX_PINCM37)
/* Defines for PA22: GPIOA.22 with pinCMx 47 on package pin 26 */
#define GPIO_PULLDOWN_GROUP_PA22_PIN                            (DL_GPIO_PIN_22)
#define GPIO_PULLDOWN_GROUP_PA22_IOMUX                           (IOMUX_PINCM47)
/* Defines for PA25: GPIOA.25 with pinCMx 55 on package pin 29 */
#define GPIO_PULLDOWN_GROUP_PA25_PIN                            (DL_GPIO_PIN_25)
#define GPIO_PULLDOWN_GROUP_PA25_IOMUX                           (IOMUX_PINCM55)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_SMPL_CLK_init(void);
void SYSCFG_DL_SESSION_ZEROED_CLOCK_init(void);
void SYSCFG_DL_SAMPLE_TIME_REFERENCE_init(void);
void SYSCFG_DL_SPI_1_USD_init(void);
void SYSCFG_DL_SPI_0_INTAN_init(void);
void SYSCFG_DL_DMA_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
