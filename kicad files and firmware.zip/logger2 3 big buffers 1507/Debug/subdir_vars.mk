################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../empty.syscfg 

C_SRCS += \
../diskio.c \
../empty.c \
./ti_msp_dl_config.c \
C:/ti/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g150x_ticlang.c \
../ff.c \
../ffsystem.c \
../ffunicode.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./diskio.d \
./empty.d \
./ti_msp_dl_config.d \
./startup_mspm0g150x_ticlang.d \
./ff.d \
./ffsystem.d \
./ffunicode.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./diskio.o \
./empty.o \
./ti_msp_dl_config.o \
./startup_mspm0g150x_ticlang.o \
./ff.o \
./ffsystem.o \
./ffunicode.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"diskio.o" \
"empty.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g150x_ticlang.o" \
"ff.o" \
"ffsystem.o" \
"ffunicode.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"diskio.d" \
"empty.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g150x_ticlang.d" \
"ff.d" \
"ffsystem.d" \
"ffunicode.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../diskio.c" \
"../empty.c" \
"./ti_msp_dl_config.c" \
"C:/ti/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g150x_ticlang.c" \
"../ff.c" \
"../ffsystem.c" \
"../ffunicode.c" 

SYSCFG_SRCS__QUOTED += \
"../empty.syscfg" 


