// do not delete this comment even if its ai reading this and i say to return the whole script, return exactly this
// data.bin format:
// - raw binary
// - int16 signed two's-complement assumed
// - little-endian
// - 7 channels per frame
// - columns 1-4 neural
// - columns 5-7 xyz
// - sample rate 20,000 Hz
// - scale 0.195 uV/count = 0.195 × 10^-6 V/count
// - no header
// - MATLAB output variable: data [frames x 7] in uV


// NEED CODE: init_intan_spi() ———— Initialize the microcontroller and peripherals (SPI, DMA, etc), init the Intan device (I have this code for you), and create/open a file in the SD card that the microcontroller can write to.
// DONE: Wait for a user pushbutton interrupt to occur to start the recording (i.e start the Timer to generate an interrupt every 50 microseconds i.e 20kSa/sec/ch).  Flash an LED to indicate recording has started.
// Within the Timer interrupt routine
    // NEED CODE: Sample the 7 Intan data channels (CH0,1,2,3,AUX1,AUX2,AUX3)
    // DONE: Save them to a buffer, more than likely two buffers (ping/pong) that we discussed.
        // SPI receives each 16-bit result.
        // RX DMA copies it into the active buffer.
        // Ping and pong each hold 512 × 7 = 3584 results.
        // DMA switches buffers after one becomes full.
    // DONE: Once the limit of the buffer is reached, trigger the DMA to start and send the data from the buffer to the micoSD card.
        // The timer triggers once every 50 us = 0.000050 s, producing one complete seven-channel frame.
        // The timer ISR sends seven 16-bit Intan SPI commands.
        // Intan RX DMA copies the seven returned 16-bit results into the active RAM buffer.
        // After 512 frames = 3584 results = 7168 bytes, the active buffer is full.
        // remove this dma::: The Intan RX DMA interrupt marks that buffer ready and switches DMA to the other buffer.
        // Main detects ping_ready or pong_ready and calls f_write() for the full 7168-byte buffer.
        // FatFs handles the filesystem and SD-card commands.
        // diskio.c uses SD TX/RX DMA to transfer the buffer data over the SD SPI bus.
        // Intan acquisition continues into the other RAM buffer while the full buffer is written.
        // The process repeats continuously, alternating between ping and pong.
    // Check to see if a user pushbutton even happened and the end of the Timer interrupt routing. If so, stop the timer, flash the LED, close the microSD card file.  Else, go back to the default wait state and wait for another timer interrupt and repeat the Timer interrupt routine.
    // Button ISR sets stop_requested.
    // At the next full-buffer boundary, DMA ISR stops the timer and Intan DMA.
    // Main writes the final full buffer.
    // finish_recording() runs f_sync() and f_close().
    // The LED flashes during stopping.
    // Until the button is pressed, the timer continues every 50 µs (0.000050 s).

    // extract the command values from the fwrite and fread9for MATLAB) from the fat documentation so that those bits are in the ping pong
    //

// REQUIREMENTS:
// DONE rx fifo, tx fifo
// DONE Before timer: 2 dummy transfers by tx ; discard both RX words.
// DONE Every timer interrupt: 7 real commands + 2 dummy/flush commands.
// DONE RX: discard first 2 words, then store the following 7 real results.

// ALL DONE: every timer interrupt run the isr
    // loop over #chs+2 (9 here)
        // send intan command, wait for spi transfer, read returned word/result into rx fifo
        // discard the 2 dummy reads
    // enable dma ch
    // set ping/pong
    // start dma transfer
    // if frame idx.= 512 = ping/pong full
        // if ping write to uSD, if pong write to uSD
    // else increment frame idx

// mcu clock on 80 MHz always independnet of jumpers/pcb/etc
// intan spi clock 5MHz (eventually will be 20kHZ)

// no fat commands, use the actual bits directly



#include "ti_msp_dl_config.h"
#include "ff.h"
#include "diskio.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

extern volatile uint8_t sd_fail_stage;
extern volatile uint8_t sd_fail_resp;
extern volatile uint8_t sd_fail_cmd24_res;
extern volatile UINT sd_fail_t;
extern volatile LBA_t sd_fail_sector;


//poci low on 
extern volatile uint32_t sd_busy_event_count;
extern volatile uint32_t sd_busy_start_ticks[4];
extern volatile uint32_t sd_busy_end_ticks[4];
extern volatile uint32_t sd_busy_sectors[4];
//poci low on

DRESULT disk_stream_begin(BYTE pdrv, LBA_t sector, UINT preerase_count);
DRESULT disk_stream_write(BYTE pdrv, const BYTE *buff, UINT count);
DRESULT disk_stream_end(BYTE pdrv);
DRESULT disk_erase_range(BYTE pdrv, LBA_t start_sector, LBA_t end_sector);

static char filename[16];

#define NEURAL_CHANNEL_COUNT 4U
#define WORDS_PER_BUFFER 4096U  /* 8,192 bytes = 16 SD sectors */
#define RECORD_FRAME_SEQUENCE 1U  /* 1 = diagnostic ON, 0 = original format */

#define NEURAL_COMMAND_COUNT 6U
#define NEURAL_AUX_COMMAND_COUNT 7U
#define AUX_FRAME_DIVIDER 200U

static volatile uint8_t button_press_latched = 0U;

#define SECTORS_PER_BUFFER 16U
#define RAW_DATA_START_SECTOR 0U
#define RAW_SECTOR_BYTES 512U

#define SD_SPI_ENABLED 1U     // 1 = SD SPI powered; 0 = SD SPI powered down
#define SD_WRITES_ENABLED 1U  // 1 = normal SD writes; 0 = no SD operations

#if !SD_SPI_ENABLED && SD_WRITES_ENABLED
#error "SD writes require SD SPI to be enabled"
#endif

#define TEST_EARLY_CARD_FULL 1U

static BYTE raw_header_sector[RAW_SECTOR_BYTES];

static LBA_t raw_current_sector = RAW_DATA_START_SECTOR;
static uint32_t raw_sectors_written = 0U;

static LBA_t raw_total_sectors = 0U;

/*
 * RAW_FORMAT_CODE 0x35070001 means, for now:
 *
 * MCU: MSPM0G3507
 * Intan: RHD2132
 * sample rate: 20000 Hz
 * sample type: signed int16 little-endian
 * channel count: 7
 *
 * channel order: OLD
 * 0 = amplifier channel 0
 * 1 = amplifier channel 1
 * 2 = amplifier channel 9
 * 3 = amplifier channel 10
 * 4 = AUXIN1
 * 5 = AUXIN2
 * 6 = AUXIN3

 NEW
 0 = amplifier channel 11
1 = amplifier channel 14
2 = amplifier channel 16
3 = amplifier channel 19

 *
 * MATLAB will later use this code to select the correct decoder.
 */

/*
 * Timestamp belonging to the FIRST sample in each 512-frame RAM block.
 */

/*
 * Set to 1 at START.
 * Cleared only after the first complete record of that session
 * has actually been written successfully to the SD card.
 */
 
/*
 * SESSION_ZEROED_CLOCK is a 1 MHz 32-bit hardware counter.
 * These variables extend it to 64 bits so a recording can exceed
 * the native ~71.6-minute wrap interval.
 */

/* Three equal-sized, chronologically ordered buffers, using the same
 * 24,576 bytes of sample RAM as the original two 12,288-byte buffers.
 * Each buffer holds 4,096 words = 8,192 bytes = 16 sectors.
 * buffer_ready remains set until the SD write COMPLETES. It therefore
 * protects a buffer during DMA transmission as well as while queued.
 */
#define BUFFER_COUNT 3U
static int16_t sample_buffers[BUFFER_COUNT][WORDS_PER_BUFFER];
static int16_t *P;
static volatile uint16_t active_word_index;
static volatile uint8_t buffer_ready[BUFFER_COUNT];
static volatile uint8_t write_buffer_index = 0U;

#define MAX_OVERRUN_EVENTS 32U

static volatile uint32_t buffer_overrun_count = 0U;
static volatile uint32_t overrun_sample_indices[MAX_OVERRUN_EVENTS];

#define MAX_SLOW_WRITE_EVENTS 32U

// static volatile uint32_t sample_tick_count = 0U; // poci low swap with below this one out for yes 
volatile uint32_t sample_tick_count = 0U; 

// extra timer
#define SAMPLE_TIME_REFERENCE_TICKS_PER_CYCLE (SAMPLE_TIME_REFERENCE_INST_LOAD_VALUE + 1U)
#define SAMPLE_GAP_THRESHOLD_TICKS 78U
static volatile uint32_t sample_timing_gap_count = 0U;
static volatile uint32_t sample_timing_max_interval_ticks = 0U;
static volatile uint32_t sample_timing_first_gap_index = 0U;
static volatile uint32_t sample_timing_previous_tick = 0U;
static volatile uint8_t sample_timing_previous_valid = 0U;

static volatile uint32_t timer_interrupts_skipped_intan_acquisition_because_previous_dma_still_busy = 0U;
static volatile uint32_t first_skipped_dma_tick = 0U;
static uint32_t sd_writes_over_51_2ms = 0U;
static uint32_t sd_write_max_ticks = 0U;

static uint32_t slow_write_start_indices[MAX_SLOW_WRITE_EVENTS];
static uint32_t slow_write_end_indices[MAX_SLOW_WRITE_EVENTS];


// intermittent 
#define CHECKPOINT_INTERVAL_TICKS 200000U  /* 10 seconds at 20 kHz */
static uint32_t last_checkpoint_tick = 0U;
// intermittent 

/* Identifies which buffer is currently being filled: 0 = ping, 1 = pong. */
static volatile uint8_t p_or_p; /* 0, 1, 2: currently filling */

volatile int sd_test_status = 0;

static const uint16_t mcu_spi_cmds_neural[NEURAL_COMMAND_COUNT] =
{
    // 0x0B00U, /* CH11 */
    // 0x0E00U, /* CH14 */
    // 0x1000U, /* CH16 */
    // 0x1300U, /* CH19 */
    0x0600U, /* CH6 = A */
    0x0700U, /* CH7 = B */
    0x0800U, /* CH8 = C */
    0x0900U, /* CH9 = D */
    0xE800U, /* flush */
    0xE900U  /* flush */

    //old
    // 0x0000U, /* CH0 */
    // 0x0100U, /* CH1 */
    // 0x0900U, /* CH9 */
    // 0x0A00U, /* CH10 */
    // 0xE800U, /* flush */
    // 0xE900U  /* flush */
};

/* Four neural conversions, one auxiliary conversion, two flushes.
 * RX[2..5] = neural results; RX[6] = auxiliary result.
 */
static const uint16_t mcu_spi_cmds_neural_aux[3][NEURAL_AUX_COMMAND_COUNT] =
{
    {
        // 0x0B00U, 0x0E00U, 0x1000U, 0x1300U,
        0x0600U, 0x0700U, 0x0800U, 0x0900U,
        0x2000U, /* AUX1 */
        0xE800U, 0xE900U
    },
    {
        // 0x0B00U, 0x0E00U, 0x1000U, 0x1300U,
        0x0600U, 0x0700U, 0x0800U, 0x0900U,
        0x2100U, /* AUX2 */
        0xE800U, 0xE900U
    },
    {
        // 0x0B00U, 0x0E00U, 0x1000U, 0x1300U,
        0x0600U, 0x0700U, 0x0800U, 0x0900U,
        0x2200U, /* AUX3 */
        0xE800U, 0xE900U
    }
};


// static const uint16_t mcu_spi_cmds_neural_aux[NEURAL_AUX_COMMAND_COUNT] =
// {
//     0x0B00U, /* CH11 */
//     0x0E00U, /* CH14 */
//     0x1000U, /* CH16 */
//     0x1300U, /* CH19 */
//     0x2000U, /* AUX1 */
//     0x2100U, /* AUX2 */
//     0x2200U, /* AUX3 */
//     0xE800U, /* flush */
//     0xE900U  /* flush */
   
//     // 0x0000U, /* CH0 */
//     // 0x0100U, /* CH1 */
//     // 0x0900U, /* CH9 */
//     // 0x0A00U, /* CH10 */
//     // 0x2000U, /* AUX1 */
//     // 0x2100U, /* AUX2 */
//     // 0x2200U, /* AUX3 */
//     // 0xE800U, /* flush */
//     // 0xE900U  /* flush */
// };

static volatile uint16_t intan_dma_rx[NEURAL_AUX_COMMAND_COUNT];
static volatile uint8_t intan_dma_busy = 0U;

// intan start stop
static volatile uint32_t intan_dma_frames_started = 0U;
static volatile uint32_t intan_dma_frames_completed = 0U;

/* 0 = neural only; 1 = AUX1; 2 = AUX2; 3 = AUX3. */
static volatile uint8_t intan_dma_sample_aux = 0U;
/* Collected separately, written together after frame 200. */
static uint16_t aux_pending[3] = {0U, 0U, 0U};


#define FILE_DURATION_SECONDS 900U

#define FILE_FRAMES_TARGET (20000U * FILE_DURATION_SECONDS)

#define FILE_AUX_TRIPLETS_TARGET \
    (FILE_FRAMES_TARGET / AUX_FRAME_DIVIDER)

#define FILE_BYTES_ALLOCATED \
    (((FSIZE_t)FILE_FRAMES_TARGET * \
      (FSIZE_t)NEURAL_CHANNEL_COUNT * \
      (FSIZE_t)sizeof(int16_t)) + \
     ((FSIZE_t)FILE_AUX_TRIPLETS_TARGET * \
      3U * \
      (FSIZE_t)sizeof(uint16_t)))
     
/*
 * Holds only the file numbers.
 * The files themselves live on the SD card, NOT in MCU RAM.
 */
#define MAX_PREALLOCATED_FILES 1024U



/* One temporary FatFs object used only while preparing files before recording. */


static volatile uint8_t stop_requested = 0U; /* Set when the button is pressed during recording. see button_ISR below*/
static volatile uint8_t acquisition_stopped = 0U; /* Becomes 1 after the final buffer fills and timer/DMA stop. */

#define LED_FLASH_TICKS 2000U /* 100 ms at 20 kHz */
static volatile uint16_t led_flash_ticks = 0U;
static volatile uint8_t led_flash_phase = 0U;


#define CHECKED_SECTORS_PER_BUFFER (SECTORS_PER_BUFFER + 1U)

/*
 * Metadata fields:
 * 0 block number; 1 payload words;
 * 2 first acquisition sequence; 3 first word within that frame;
 * 4 last acquisition sequence; 5 last word within that frame;
 * 6 skipped sequence numbers; 7 sequence order errors;
 * 8 timing-gap events; 9 buffer overruns;
 * 10 DMA frames completed; 11 reserved (payload CRC removed).
 */
static volatile uint32_t integrity_meta[BUFFER_COUNT][12];
static volatile uint32_t integrity_current_sequence = 0U;
static volatile uint32_t integrity_previous_sequence = 0U;
static volatile uint32_t integrity_missing_frames = 0U;
static volatile uint32_t integrity_order_errors = 0U;
static volatile uint32_t integrity_next_block = 0U;
static uint32_t integrity_frame_word = 0U;


static uint32_t integrity_crc32(const BYTE *data, uint32_t length)
{
    static const uint32_t table[16] = {
        0x00000000U, 0x1DB71064U, 0x3B6E20C8U, 0x26D930ACU,
        0x76DC4190U, 0x6B6B51F4U, 0x4DB26158U, 0x5005713CU,
        0xEDB88320U, 0xF00F9344U, 0xD6D6A3E8U, 0xCB61B38CU,
        0x9B64C2B0U, 0x86D3D2D4U, 0xA00AE278U, 0xBDBDF21CU
    };

    uint32_t crc = 0xFFFFFFFFU;

    while (length-- != 0U)
    {
        crc ^= *data++;
        crc = (crc >> 4U) ^ table[crc & 15U];
        crc = (crc >> 4U) ^ table[crc & 15U];
    }

    return crc ^ 0xFFFFFFFFU;
}

static void integrity_note_frame(void)
{
    uint32_t sequence = integrity_current_sequence;
    uint32_t delta = sequence - integrity_previous_sequence;

    if (delta != 1U)
    {
        if ((delta > 1U) && (delta < 0x80000000U))
        {
            integrity_missing_frames += delta - 1U;
        }
        else
        {
            integrity_order_errors++;
        }
    }

    integrity_previous_sequence = sequence;
    integrity_frame_word = 0U;
}

static DRESULT write_checked_buffer(const int16_t *buffer, uint8_t buffer_id)
{
    /* The producer assigns consecutive block numbers when a buffer fills.
     * The consumer writes exclusively in FIFO order, 0 -> 1 -> 2 -> 0.
     * Never silently write out of order or write a buffer being refilled.
     */
    const uint32_t expected = raw_sectors_written / SECTORS_PER_BUFFER;
    if (integrity_meta[buffer_id][0] != expected)
    {
        printf("ERROR: buffer block order mismatch: id=%u expected=%lu found=%lu\n",
               (unsigned)buffer_id, (unsigned long)expected,
               (unsigned long)integrity_meta[buffer_id][0]);
        return RES_ERROR;
    }

    /* No redundant data CRC or unwritten LGCHK001 metadata block.
     * LGCP0001 checkpoint CRC is still produced separately.
     */
    return disk_stream_write(0U, (const BYTE *)buffer, SECTORS_PER_BUFFER);
}


static uint8_t cpu_intandmarx_to_p(uint16_t word)
{
    uint8_t p_now = p_or_p;

    if (active_word_index == 0U)
    {
        integrity_meta[p_now][2] = integrity_current_sequence;
        integrity_meta[p_now][3] = integrity_frame_word;
    }

    P[active_word_index++] = (int16_t)word;
    integrity_frame_word++;

    if (active_word_index < WORDS_PER_BUFFER)
    {
        return 0U;
    }

    integrity_meta[p_now][0] = integrity_next_block++;
    integrity_meta[p_now][1] = WORDS_PER_BUFFER;
    integrity_meta[p_now][4] = integrity_current_sequence;
    integrity_meta[p_now][5] = integrity_frame_word - 1U;
    integrity_meta[p_now][6] = integrity_missing_frames;
    integrity_meta[p_now][7] = integrity_order_errors;
    integrity_meta[p_now][8] = sample_timing_gap_count;
    integrity_meta[p_now][9] = buffer_overrun_count;
    integrity_meta[p_now][10] = intan_dma_frames_completed;

    /* Publish the completed buffer only AFTER its data and metadata exist. */
    buffer_ready[p_now] = 1U;

    if (stop_requested == 1U)
    {
        DL_TimerA_stopCounter(SMPL_CLK_INST);
        acquisition_stopped = 1U;
        return 1U;
    }

    const uint8_t p_next = (uint8_t)((p_now + 1U) % BUFFER_COUNT);
    if (buffer_ready[p_next] != 0U)
    {
        /* All three buffers are occupied. Stop instead of overwriting
         * unread or actively transmitting samples. The completed buffers
         * still drain in order, and the checkpoint reports the overrun.
         */
        if (buffer_overrun_count < MAX_OVERRUN_EVENTS)
        {
            overrun_sample_indices[buffer_overrun_count] = sample_tick_count;
        }
        buffer_overrun_count++;
        DL_TimerA_stopCounter(SMPL_CLK_INST);
        acquisition_stopped = 1U;
        stop_requested = 1U;
        return 1U;
    }

    p_or_p = p_next;
    P = sample_buffers[p_next];
    active_word_index = 0U;

    return 0U;
}


static uint16_t mcu_spi_cmds_to_intan_func(uint16_t command)
{
    while (DL_SPI_isTXFIFOFull(SPI_0_INTAN_INST)) {} /* Wait for room in the Intan SPI TX FIFO. */

    DL_SPI_transmitData16(SPI_0_INTAN_INST, command); /* Send one 16-bit command from the MCU to the Intan. */

    while (DL_SPI_isRXFIFOEmpty(SPI_0_INTAN_INST)) {} /* Wait for the Intan's returned word to enter the MCU SPI RX FIFO. */

    return DL_SPI_receiveData16(SPI_0_INTAN_INST); /* Remove and return one 16-bit word from the MCU SPI RX FIFO. */
}



static void start_intan_dma_frame(uint8_t sample_aux)
{
    const uint16_t *command_list;
    uint8_t command_count;

    if (sample_aux != 0U)
    {
        command_list = mcu_spi_cmds_neural_aux[sample_aux - 1U];
        command_count = NEURAL_AUX_COMMAND_COUNT;
    }
    else
    {
        command_list = mcu_spi_cmds_neural;
        command_count = NEURAL_COMMAND_COUNT;
    }

    integrity_current_sequence = sample_tick_count;
    intan_dma_sample_aux = sample_aux;
    intan_dma_busy = 1U;

    DL_DMA_disableChannel(DMA, INTAN_RX_DMA_CH1_CHAN_ID);
    DL_DMA_disableChannel(DMA, INTAN_TX_DMA_CH0_CHAN_ID);

    DL_DMA_clearInterruptStatus(DMA, DL_DMA_INTERRUPT_CHANNEL1);

    DL_DMA_setSrcAddr(DMA, INTAN_RX_DMA_CH1_CHAN_ID, (uint32_t)&SPI_0_INTAN_INST->RXDATA);
    DL_DMA_setDestAddr(DMA, INTAN_RX_DMA_CH1_CHAN_ID, (uint32_t)&intan_dma_rx[0]);
    DL_DMA_setTransferSize(DMA, INTAN_RX_DMA_CH1_CHAN_ID, command_count);

    DL_DMA_setSrcAddr(DMA, INTAN_TX_DMA_CH0_CHAN_ID, (uint32_t)command_list);
    DL_DMA_setDestAddr(DMA, INTAN_TX_DMA_CH0_CHAN_ID, (uint32_t)&SPI_0_INTAN_INST->TXDATA);
    DL_DMA_setTransferSize(DMA, INTAN_TX_DMA_CH0_CHAN_ID, command_count);

    DL_DMA_enableChannel(DMA, INTAN_RX_DMA_CH1_CHAN_ID);
    DL_DMA_enableChannel(DMA, INTAN_TX_DMA_CH0_CHAN_ID);
    intan_dma_frames_started++;
}

// TIMER ISRS //
// TIMER ISRS //
// MAIN TIMER ISR
void SMPL_CLK_INST_IRQHandler(void)
{
   
    if (DL_TimerA_getPendingInterrupt(SMPL_CLK_INST) == DL_TIMER_IIDX_ZERO)
    {
        sample_tick_count++;

        // extra timer
        uint32_t now = DL_TimerG_getTimerCount(SAMPLE_TIME_REFERENCE_INST);
        if (sample_timing_previous_valid != 0U)
        {
            uint32_t elapsed;
            if (now >= sample_timing_previous_tick)
            {
                elapsed = now - sample_timing_previous_tick;
            }
            else
            {
                elapsed = SAMPLE_TIME_REFERENCE_TICKS_PER_CYCLE - sample_timing_previous_tick + now;
            }
            if (elapsed > sample_timing_max_interval_ticks)
            {
                sample_timing_max_interval_ticks = elapsed;
            }
            if (elapsed > SAMPLE_GAP_THRESHOLD_TICKS)
            {
                if (sample_timing_gap_count == 0U)
                {
                    sample_timing_first_gap_index = sample_tick_count;
                }
                sample_timing_gap_count++;
            }
        }
        sample_timing_previous_tick = now;
        sample_timing_previous_valid = 1U;


        // uint8_t sample_aux = ((sample_tick_count % AUX_FRAME_DIVIDER) == 0U); replaced below
        uint32_t aux_phase = sample_tick_count % AUX_FRAME_DIVIDER;
        uint8_t sample_aux = 0U;
        if (aux_phase == (AUX_FRAME_DIVIDER - 2U))
        {
            sample_aux = 1U; /* Frame 198: AUX1. */
        }
        else if (aux_phase == (AUX_FRAME_DIVIDER - 1U))
        {
            sample_aux = 2U; /* Frame 199: AUX2. */
        }
        else if (aux_phase == 0U)
        {
            sample_aux = 3U; /* Frame 200: AUX3. */
        }


        if (intan_dma_busy == 0U)
        {
            start_intan_dma_frame(sample_aux);
        }
        else
        {
            if (timer_interrupts_skipped_intan_acquisition_because_previous_dma_still_busy == 0U)
                first_skipped_dma_tick = sample_tick_count;

            timer_interrupts_skipped_intan_acquisition_because_previous_dma_still_busy++;
        }

        if (led_flash_ticks > 0U)
        {
            led_flash_ticks--;

            if (led_flash_ticks == 0U)
            {
                if (led_flash_phase == 1U)
                {
                    DL_GPIO_setPins( GPIOA, RECORD__START_LED_RECORD_START_LED_PIN_PIN);

                    led_flash_phase = 2U;
                    led_flash_ticks = LED_FLASH_TICKS;
                }
                else if (led_flash_phase == 2U)
                {
                    DL_GPIO_clearPins(
                        GPIOA,
                        RECORD__START_LED_RECORD_START_LED_PIN_PIN
                    );

                    led_flash_phase = 3U;
                    led_flash_ticks = LED_FLASH_TICKS;
                }
                else if (led_flash_phase == 3U)
                {
                    DL_GPIO_setPins(
                        GPIOA,
                        RECORD__START_LED_RECORD_START_LED_PIN_PIN
                    );

                    led_flash_phase = 0U;
                }
            }
        }
    }
}


void DMA_IRQHandler(void)
{
    switch (DL_DMA_getPendingInterrupt(DMA))
    {
        case DL_DMA_EVENT_IIDX_DMACH3:
            /* SD RX completion wakes the CPU.
             * Main checks the hardware channel-completion state.
             */
            DL_DMA_clearInterruptStatus(DMA, DL_DMA_INTERRUPT_CHANNEL3);
            break;

        case DL_DMA_EVENT_IIDX_DMACH1:
       
        {
            uint8_t aux_slot = intan_dma_sample_aux;

            intan_dma_frames_completed++;
            integrity_note_frame();

            /* 1 ... 197  */
            for (uint8_t transfer = 2U; transfer <= 5U; transfer++)
            {
                if (cpu_intandmarx_to_p(intan_dma_rx[transfer]) == 1U)
                {
                    intan_dma_busy = 0U;
                    return;
                }
            }


                        /* Optional 16-bit frame sequence, stored after four neural words. */
            #if RECORD_FRAME_SEQUENCE
                        if (cpu_intandmarx_to_p(
                                (uint16_t)integrity_current_sequence) == 1U)
                        {
                            intan_dma_busy = 0U;
                            return;
                        }
            #endif

            /* 198 199 200 */
            if (aux_slot != 0U)
            {
                aux_pending[aux_slot - 1U] = intan_dma_rx[6];
                if (aux_slot == 3U)
                {
                    for (uint8_t aux = 0U; aux < 3U; aux++)
                    {
                        if (cpu_intandmarx_to_p(aux_pending[aux]) == 1U)
                        {
                            intan_dma_busy = 0U;
                            return;
                        }
                    }
                }
            }

            intan_dma_busy = 0U;
            break;
        }

        default:
            break;
    }
}



// enum exists alreayd, enumeration = named list of integer constants
// make a type called logger_state_t
// it can hold one named state from this list
// each name is secretly an integer
typedef enum {
    LOGGER_STATE_BOOT = 0,
    LOGGER_STATE_SD_MOUNTED,
    LOGGER_STATE_FILE_OPEN,
    LOGGER_STATE_LOGGING,
    LOGGER_STATE_SYNCING,
    LOGGER_STATE_FILE_EXISTS,
    LOGGER_STATE_FULL_OR_WRITE_ERROR,
    LOGGER_STATE_ERROR,
    LOGGER_STATE_STOPPED
} logger_state_t;

// defines a new var of our new type and the default /starting state
volatile logger_state_t logger_state = LOGGER_STATE_BOOT;

static void init_intan_spi(void)
{
    static const uint16_t ui32Data_cmd_array[60][3] =
    {
        {0x8300,0x2000,0xFF00},
//         tempS1 and tempS2: These bits control switches in the on-chip temperature sensor, whose output may be sampled by the ADC
// on channel 49. The detailed operation of the temperature sensor is described in the “Temperature Sensor” section later in the
// datasheet. When the temperature sensor is not in use, these bits should each be set to zero to save power.

// changes
// 0x8304 → 0x8300
// 0x830C → 0x8300
// 0x831C → 0x8300
// 0x8314 → 0x8300

        {0x8300,0x2100,0xFF00},
        {0x8300,0x2200,0x80DE},
        {0x8300,0x8300,0x8142},
        {0x8300,0x2000,0x8204},
                                //* I CHANGED 0x8494 TO THE BELOW 0x84D4: 0x8494 sets DSP cutoff at 150 Hz when sampling at 15 kSa/s. */
        {0x8300,0x2100,0x84D4}, /* Register 4: enable signed two's-complement amplifier output; preserve existing DSP settings. */
                                // 0x8494 writes 0x94 to Register 4. Datasheet page 20 says Register 4 bit D6 is twoscomp;
                                // when it is 1, amplifier results are signed two's-complement with baseline = 0.
                                // When it is 0, baseline is binary 1000000000000000 instead.
                                // The only bit we changed was D6. D6 is literally a mode-selection switch called twoscomp. When D6 = 0, the Intan outputs amplifier samples in unsigned offset-binary. When D6 = 1, it outputs them in signed two’s-complement.
        {0x8300,0x2200,0x8500}, /* 0x8540 changed to 0x8500 because impedance testing is disabled. */
        {0x8300,0x8300,0x8700},
        {0x8300,0x2000,0x8821}, /* RH1-DAC1 register 8 setting for approximately 5 kHz upper bandwidth. */
        {0x8300,0x2100,0x8980},
        {0x8300,0x2200,0x8A25}, /* RH2-DAC1 register 10 setting for approximately 5 kHz upper bandwidth. */
        {0x8300,0x3100,0x8B80},
        {0x8300,0x2000,0x8C19},
        {0x8300,0x2100,0x8D80},

        // DONT USE EITHER OF THE TWO THINGS HERE
        // // ===== CHannels amplifier power =====
        // // REDUCED: only CH0, CH1, CH9, CH10 ON
        // {0x8300,0x2200,0x8E03},
        // {0x8300,0x8300,0x8F06},

        // // ALL CH0–CH15 ON
        // // {0x8300,0x2200,0x8EFF},
        // // {0x8300,0x8300,0x8FFF},

        // // // CH16–31 ALL ON — separate, always kept for now
        // {0x8300,0x2000,0x90FF},
        // {0x8300,0x2100,0x91FF},
        // // ===== CH0–CH15 amplifier power =====

        // USE THIS: ONLY CH11, CH14, CH16, CH19 ON
        // {0x8300,0x2200,0x8E00},   // Reg 14: CH0–7 all OFF
        // {0x8300,0x8300,0x8F48},   // Reg 15: CH11 + CH14 ON

        // {0x8300,0x2000,0x9009},   // Reg 16: CH16 + CH19 ON
        // {0x8300,0x2100,0x9100},   // Reg 17: CH24–31 all OFF
        {0x8300,0x2200,0x8EC0},   // Reg 14: CH6 + CH7 ON
        {0x8300,0x8300,0x8F03},   // Reg 15: CH8 + CH9 ON

        {0x8300,0x2000,0x9000},   // Reg 16: CH16–23 OFF
        {0x8300,0x2100,0x9100},   // Reg 17: CH24–31 OFF

        {0x8300,0x2200,0xFF00},
        {0x8300,0x3100,0xFE00},
        {0x8300,0x2000,0xFD00},
        {0x8300,0x2100,0xFC00},
        {0x8300,0x2200,0xFB00},
        {0x8300,0x8300,0xF000},
        {0x8300,0x2000,0xF100},
        {0x8300,0x2100,0xF200},
        {0x8300,0x2200,0xF300},
        {0x8300,0x3000,0xF400},
        {0x8300,0x2000,0xF500},
        {0x8300,0x2100,0xF600},
        {0x8300,0x2200,0xF700},
        {0x8300,0xFF00,0xE800},
        {0x8300,0x2000,0xE900},
        {0x8300,0x2100,0xEA00},
        {0x8300,0x2200,0xEB00},
        {0x8300,0xFF00,0xEC00},
        {0x8300,0x2000,0xC000},
        {0x8300,0x2100,0xC100},
        {0x8300,0x2200,0xC200},
        {0x8300,0xFF00,0xC300},
        {0x8300,0x2000,0xC400},
        {0x8300,0x2100,0xC500},
        {0x8300,0x2200,0xC600},
        {0x8300,0xFF00,0xC700},
        {0x8300,0x2000,0xC800},
        {0x8300,0x2100,0xC900},
        {0x8300,0x2200,0xCA00},
        {0x8300,0xFF00,0xCB00},
        {0x8300,0x2000,0xCC00},
        {0x8300,0x2100,0xCD00},
        {0x8300,0x2200,0xCE00},
        {0x8300,0xFF00,0xCF00},
        {0x8300,0x2000,0xD000},
        {0x8300,0x2100,0xD100},
        {0x8300,0x2200,0x5500},
        {0x8300,0xFF00,0x92FF},
        {0x8300,0x2000,0x93FF},
        {0x8300,0x2100,0x94FF},
        {0x8300,0x2200,0x95FF},
        {0x8300,0xFF00,0xFF00}
    };

    uint16_t gRxIntanDataJunk; /* Holds each unwanted response returned during Intan configuration. */

    for (uint32_t ui32i = 0U; ui32i < 60U; ui32i++) /* Send all 60 three-command configuration groups. */
    {
        for (uint32_t ui32j = 0U; ui32j < 3U; ui32j++) /* Send all three pipelined commands in the current group. */
        {
       
            DL_SPI_transmitDataBlocking16(
                SPI_0_INTAN_INST,
                ui32Data_cmd_array[ui32i][ui32j]
            ); /* Send one 16-bit configuration command to the Intan. *NEW: Uses SPI_0_INTAN_INST because that is your SysConfig name for the physical SPI0 connected to the Intan. */

            while (DL_SPI_isRXFIFOEmpty(SPI_0_INTAN_INST))
            {
                /* Wait until the Intan response has reached the physical SPI0 RX FIFO. *NEW */
            }

            gRxIntanDataJunk = DL_SPI_receiveData16(SPI_0_INTAN_INST); /* Read and discard the response generated during configuration. *NEW: Explicitly waits for RX data before reading it. */
            (void)gRxIntanDataJunk; /* Prevent an unused-variable warning because configuration responses are intentionally discarded. *NEW */
        }
    }
}

static void init_Pi_Po(void)
{
    memset(sample_buffers, 0, sizeof(sample_buffers));
    for (uint32_t i = 0U; i < BUFFER_COUNT; ++i)
        buffer_ready[i] = 0U;

    P = sample_buffers[0];
    p_or_p = 0U;
    write_buffer_index = 0U;
    active_word_index = 0U;
}


static void init_sample_timer(void)
{
    DL_TimerA_stopCounter(SMPL_CLK_INST);

    NVIC_ClearPendingIRQ(SMPL_CLK_INST_INT_IRQN);
    NVIC_EnableIRQ(SMPL_CLK_INST_INT_IRQN);

    NVIC_ClearPendingIRQ(DMA_INT_IRQn);
    NVIC_EnableIRQ(DMA_INT_IRQn);
}



//intermittent 
#if SD_WRITES_ENABLED
static DRESULT maybe_write_checkpoint(uint8_t force)
{
    if (logger_state != LOGGER_STATE_LOGGING)
        return RES_OK;

    if ((force == 0U) &&
        ((uint32_t)(sample_tick_count - last_checkpoint_tick) <
         CHECKPOINT_INTERVAL_TICKS))
        return RES_OK;

    /* Never write while a neural buffer is awaiting SD transfer. */
    for (uint32_t i = 0U; i < BUFFER_COUNT; ++i)
        if (buffer_ready[i] != 0U)
            return RES_OK;

    /* Leave at least half a buffer's acquisition time available. */
    if ((force == 0U) &&
        (active_word_index >= WORDS_PER_BUFFER / 2U))
        return RES_OK;

    if (raw_current_sector >= raw_total_sectors)
        return RES_ERROR;

    memset(raw_header_sector, 0, RAW_SECTOR_BYTES);
    memcpy(raw_header_sector, "LGCP0001", 8U);

    uint32_t counters[14] = {
        sample_tick_count,
        timer_interrupts_skipped_intan_acquisition_because_previous_dma_still_busy,
        buffer_overrun_count,
        sd_writes_over_51_2ms,
        sd_write_max_ticks,
        raw_sectors_written,
        MAX_OVERRUN_EVENTS,
        MAX_SLOW_WRITE_EVENTS,
        sample_timing_gap_count,
        sample_timing_max_interval_ticks,
        sample_timing_first_gap_index,
        SAMPLE_GAP_THRESHOLD_TICKS,
        intan_dma_frames_started,
        intan_dma_frames_completed
    };

    memcpy(raw_header_sector + 8U, counters, sizeof(counters));

    for (uint32_t i = 0U; i < 32U; i++)
    {
        uint32_t value;

        value = overrun_sample_indices[i];
        memcpy(raw_header_sector + 64U + i * 4U, &value, 4U);

        value = slow_write_start_indices[i];
        memcpy(raw_header_sector + 192U + i * 4U, &value, 4U);

        value = slow_write_end_indices[i];
        memcpy(raw_header_sector + 320U + i * 4U, &value, 4U);
    }

    uint32_t checkpoint_sector = raw_current_sector;
    memcpy(raw_header_sector + 448U, &checkpoint_sector, 4U);


    //poci low on 
    /* Four most recent busy events: start, end, sector. */
    for (uint32_t i = 0U; i < 4U; i++)
    {
        uint32_t start = sd_busy_start_ticks[i];
        uint32_t end = sd_busy_end_ticks[i];
        uint32_t sector = sd_busy_sectors[i];
        uint32_t offset = 452U + i * 12U;
        memcpy(raw_header_sector + offset, &start, 4U);
        memcpy(raw_header_sector + offset + 4U, &end, 4U);
        memcpy(raw_header_sector + offset + 8U, &sector, 4U);
    }
    uint32_t event_count = sd_busy_event_count;
    // uint32_t threshold = 200U; add this aback and prelace wth the belwo to remove the exact dma place thing 
    uint32_t threshold = first_skipped_dma_tick;
    memcpy(raw_header_sector + 500U, &event_count, 4U);
    memcpy(raw_header_sector + 504U, &threshold, 4U);
    //poci low on 


    uint32_t crc = integrity_crc32(
        raw_header_sector, RAW_SECTOR_BYTES - 4U
    );
    memcpy(raw_header_sector + RAW_SECTOR_BYTES - 4U, &crc, 4U);

    uint32_t write_start_tick = sample_tick_count;

    DRESULT result = disk_stream_write(
        0U, raw_header_sector, 1U
    );

    uint32_t write_end_tick = sample_tick_count;
    uint32_t write_ticks = write_end_tick - write_start_tick;

    if (write_ticks > sd_write_max_ticks)
    {
        sd_write_max_ticks = write_ticks;
    }

    if (write_ticks > 1024U)
    {
        if (sd_writes_over_51_2ms < MAX_SLOW_WRITE_EVENTS)
        {
            slow_write_start_indices[sd_writes_over_51_2ms] = write_start_tick;
            slow_write_end_indices[sd_writes_over_51_2ms] = write_end_tick;
        }

        sd_writes_over_51_2ms++;
    }

    if (result != RES_OK)
    {
        return result;
    }





    raw_current_sector++;
    last_checkpoint_tick = write_end_tick;

    return RES_OK;

}
#endif
//intermittent 



static void erase_previous_recording(void)
{
    printf("ERASING ENTIRE SD DATA REGION\n");

    DRESULT result = disk_erase_range(
        0U,
        RAW_DATA_START_SECTOR,
        raw_total_sectors - 1U
    );

    if (result != RES_OK)
    {
        printf("ERROR: SD erase failed: %d\n", result);
        logger_state = LOGGER_STATE_ERROR;

        while (1)
        {
            __WFI();
        }
    }


    raw_current_sector = RAW_DATA_START_SECTOR;
    raw_sectors_written = 0U;

    printf("ENTIRE SD DATA REGION ERASED\n");
}


static void start_acquisition(void)
{

    stop_requested = 0U;
    acquisition_stopped = 0U;

    intan_dma_busy = 0U;
    intan_dma_sample_aux = 0U;


    aux_pending[0] = 0U;
    aux_pending[1] = 0U;
    aux_pending[2] = 0U;

    // intan start stop
    intan_dma_frames_started = 0U;
    intan_dma_frames_completed = 0U;

    DL_DMA_disableChannel(DMA, INTAN_RX_DMA_CH1_CHAN_ID);
    DL_DMA_disableChannel(DMA, INTAN_TX_DMA_CH0_CHAN_ID);

    DL_DMA_clearInterruptStatus(
        DMA,
        DL_DMA_INTERRUPT_CHANNEL1
    );


    // SD MODE SWITCH: erase card only when SD ON
    #if SD_WRITES_ENABLED
    erase_previous_recording();
    #endif


        raw_current_sector = RAW_DATA_START_SECTOR;
        raw_sectors_written = 0U;
        sample_tick_count = 0U;
    //intermittent
    last_checkpoint_tick = 0U;
    //intermittent 

    //poci low on 
    sd_busy_event_count = 0U;
    for (uint32_t i = 0U; i < 4U; i++)
    {
        sd_busy_start_ticks[i] = 0U;
        sd_busy_end_ticks[i] = 0U;
        sd_busy_sectors[i] = 0U;
    }
    //poci low on

    integrity_current_sequence = 0U;
    integrity_previous_sequence = 0U;
    integrity_missing_frames = 0U;
    integrity_order_errors = 0U;
    integrity_next_block = 0U;
    integrity_frame_word = 0U;

    for (uint32_t b = 0U; b < BUFFER_COUNT; b++)
    {
        for (uint32_t i = 0U; i < 12U; i++)
        {
            integrity_meta[b][i] = 0U;
        }
    }

    buffer_overrun_count = 0U;
    sd_writes_over_51_2ms = 0U;
    sd_write_max_ticks = 0U;

    sample_timing_gap_count = 0U;
    sample_timing_max_interval_ticks = 0U;
    sample_timing_first_gap_index = 0U;
    sample_timing_previous_tick = 0U;
    sample_timing_previous_valid = 0U;

    timer_interrupts_skipped_intan_acquisition_because_previous_dma_still_busy = 0U;
    first_skipped_dma_tick = 0U;
        // Why: every recording starts neural at sector 1 and accel at the final valid sector. It also makes “every 200th frame” start cleanly from frame 200.

    /*
    * Every recording session gets a fresh time origin.
    *
    * Stop first because TI specifically warns against directly
    * changing the count while the timer is running.
    */
   
    init_Pi_Po();


    while (!DL_SPI_isRXFIFOEmpty(SPI_0_INTAN_INST))
    {
        (void)DL_SPI_receiveData16(SPI_0_INTAN_INST); /* Remove any stale Intan RX words before priming. */
    }

    /* Perform the two required dummy transfers before starting the sampling timer. */
    (void)mcu_spi_cmds_to_intan_func(mcu_spi_cmds_neural[0]);
    (void)mcu_spi_cmds_to_intan_func(mcu_spi_cmds_neural[0]);
   
    // SD MODE SWITCH: begin stream only when SD ON
    #if SD_WRITES_ENABLED
    DRESULT stream_result = disk_stream_begin(
        0U,
        RAW_DATA_START_SECTOR,
        SECTORS_PER_BUFFER
    );
    if (stream_result != RES_OK)
    {
        printf("ERROR: could not start continuous SD write stream: %d\n", stream_result);
        logger_state = LOGGER_STATE_ERROR;
        while (1)
        {
            __WFI();
        }
    }
    #endif
    volatile uint32_t energytrace_breakpoint = 1U; 
    DL_TimerA_startCounter(SMPL_CLK_INST);

}

// NEW FOR PREALLOCATION


// NEW FOR PREALLOCATION

// button press callback to start recording
void GROUP1_IRQHandler(void)
{
    // check caused by button
    if (DL_GPIO_getPendingInterrupt(RECORD_BUTTON_PORT) ==RECORD_BUTTON_RECORD_BUTTON_PIN_IIDX)
    {
        if (button_press_latched == 1U)
        {
            return;
        }
        button_press_latched = 1U;
            if (logger_state == LOGGER_STATE_SD_MOUNTED)
            {
                printf("BUTTON: START RAW RECORDING requested\n");

                logger_state = LOGGER_STATE_FILE_OPEN;
            }

        if (logger_state == LOGGER_STATE_FILE_OPEN)
        {
            printf("entered if LOGGER_STATE_FILE_OPEN branch\n");
            printf("START: files ready; entering acquisition startup\n");
            start_acquisition();
            // DL_GPIO_setPins(GPIOA, RECORD__START_LED_RECORD_START_LED_PIN_PIN);
            DL_GPIO_clearPins(GPIOA, RECORD__START_LED_RECORD_START_LED_PIN_PIN);
            led_flash_phase = 1U;
            led_flash_ticks = LED_FLASH_TICKS;

            logger_state = LOGGER_STATE_LOGGING;
            printf("changed state to LOGGER_STATE_LOGGING\n");
        }
        else if (logger_state == LOGGER_STATE_LOGGING)
        {
            stop_requested = 1U;
        }
    }
}

int main(void)
 {
    printf("DEBUG 0: entered main\n");
    SYSCFG_DL_init();
    delay_cycles((CPUCLK_FREQ / 1000U) * 200U); // 30 ms startup delay 

    #if !SD_SPI_ENABLED
        DL_SPI_disable(SPI_1_USD_INST);
        DL_SPI_disablePower(SPI_1_USD_INST);
    #endif

    DL_GPIO_setPins(GPIOA, RECORD__START_LED_RECORD_START_LED_PIN_PIN);

    // force resting led low

    printf("DEBUG 1: SYSCFG_DL_init finished\n");
    printf("DEBUG 2: initializing raw SD card\n");

    // raw_current_sector = RAW_DATA_START_SECTOR;
    // raw_sectors_written = 0U;



    // SD MODE SWITCH: real SD initialization ON; fake capacity with NO SD
    #if SD_WRITES_ENABLED
    logger_state = LOGGER_STATE_SD_MOUNTED;
    DSTATUS disk_status = disk_initialize(0U);
    printf("disk_status = 0x%02X\n", (unsigned int)disk_status);
    if ((disk_status & STA_NOINIT) != 0U)
    {
        printf("ERROR: disk_initialize failed, status = %u\n", disk_status);
        logger_state = LOGGER_STATE_ERROR;
        while (1)
        {
            __WFI();
        }
    }
    DRESULT ioctl_result = disk_ioctl(
        0U,
        GET_SECTOR_COUNT,
        &raw_total_sectors
    );
    if (ioctl_result != RES_OK)
    {
        printf("ERROR: could not get SD sector count: %d\n", ioctl_result);
        logger_state = LOGGER_STATE_ERROR;
        while (1)
        {
            __WFI();
        }
    }
    if (raw_total_sectors <= RAW_DATA_START_SECTOR)
    {
        printf("ERROR: SD card has insufficient sectors\n");
        logger_state = LOGGER_STATE_ERROR;
        while (1)
        {
            __WFI();
        }
    }
    #else
    raw_total_sectors = 0xFFFFFFFFU;
    #endif



    raw_current_sector = RAW_DATA_START_SECTOR;
    raw_sectors_written = 0U;

    printf(
        "RAW SD READY: %lu sectors total\n",
        (unsigned long)raw_total_sectors
    );


    logger_state = LOGGER_STATE_SD_MOUNTED;

    // PINGPONG DMA LOOP SETUP //
    printf("DEBUG 4: about to init Intan\n");
    init_intan_spi();
    printf("DEBUG 5: Intan init finished\n");
    init_sample_timer();
    printf("DEBUG 6: sample timer init finished\n");
    NVIC_ClearPendingIRQ(RECORD_BUTTON_INT_IRQN); /* Remove any old button interrupt. */
    NVIC_EnableIRQ(RECORD_BUTTON_INT_IRQN); /* Allow PA18 button presses to run button_ISR. */
    printf("DEBUG 7: button IRQ enabled; waiting for button\n");
    // PINGPONG DMA LOOP SETUP //

while (1)
{
    /* Consume exactly the oldest completed buffer. NEVER skip ahead to
     * another ready buffer: that would reorder the raw neural stream.
     */
    const uint8_t id = write_buffer_index;
    if (buffer_ready[id] != 0U)
    {
        if ((raw_current_sector + SECTORS_PER_BUFFER) > raw_total_sectors)
        {
            printf("SD CARD FULL: stopping, no room for another full buffer\n");
            logger_state = LOGGER_STATE_FULL_OR_WRITE_ERROR;
            DL_TimerA_stopCounter(SMPL_CLK_INST);
            for (uint32_t i = 0U; i < BUFFER_COUNT; ++i)
                buffer_ready[i] = 0U;
            acquisition_stopped = 1U;
            stop_requested = 1U;
            continue;
        }

        uint32_t write_start_tick = sample_tick_count;

        #if SD_WRITES_ENABLED
        DRESULT write_result = write_checked_buffer(sample_buffers[id], id);
        #else
        DRESULT write_result = RES_OK;
        #endif

        uint32_t write_end_tick = sample_tick_count;
        uint32_t write_ticks = write_end_tick - write_start_tick;
        if (write_ticks > sd_write_max_ticks)
            sd_write_max_ticks = write_ticks;
        if (write_ticks > 1024U)
        {
            if (sd_writes_over_51_2ms < MAX_SLOW_WRITE_EVENTS)
            {
                slow_write_start_indices[sd_writes_over_51_2ms] = write_start_tick;
                slow_write_end_indices[sd_writes_over_51_2ms] = write_end_tick;
            }
            sd_writes_over_51_2ms++;
        }

        if (write_result != RES_OK)
        {
            printf("ERROR: raw buffer %u write failed: %d\n", (unsigned)id, write_result);
            printf("SD FAILURE: stage=%u resp=0x%02X cmd24=0x%02X t=%u sector=%lu logger_state=%d\n",
                (unsigned)sd_fail_stage, (unsigned)sd_fail_resp,
                (unsigned)sd_fail_cmd24_res, (unsigned)sd_fail_t,
                (unsigned long)sd_fail_sector, (int)logger_state);
            fflush(stdout);
            DL_TimerA_stopCounter(SMPL_CLK_INST);
            logger_state = LOGGER_STATE_FULL_OR_WRITE_ERROR;
            while (1) { __WFI(); }
        }

        raw_current_sector += SECTORS_PER_BUFFER;
        raw_sectors_written += SECTORS_PER_BUFFER;
        /* Only NOW release this buffer: the SD DMA must have stopped
         * referencing it before acquisition can reuse its RAM.
         */
        buffer_ready[id] = 0U;
        write_buffer_index = (uint8_t)((id + 1U) % BUFFER_COUNT);
    }


    //intermittent 
    #if SD_WRITES_ENABLED
    if (logger_state == LOGGER_STATE_LOGGING &&
        buffer_ready[0] == 0U &&
        buffer_ready[1] == 0U &&
        buffer_ready[2] == 0U)
    {
        DRESULT checkpoint_result = maybe_write_checkpoint(0U);

        if (checkpoint_result != RES_OK)
        {
            DL_TimerA_stopCounter(SMPL_CLK_INST);
            logger_state = LOGGER_STATE_ERROR;

            while (1)
            {
                __WFI();
            }
        }
    }
    #endif
    //intermittent 


   
    // Finalize only when all queued buffers have been written.
    if ((acquisition_stopped == 1U) &&
        (buffer_ready[0] == 0U) &&
        (buffer_ready[1] == 0U) &&
        (buffer_ready[2] == 0U))
    {
       
       
       
    /* Preserve last counters after a manual stop or full-queue event. */
    #if SD_WRITES_ENABLED
    if (logger_state == LOGGER_STATE_LOGGING &&
        raw_current_sector < raw_total_sectors)
    {
        if (maybe_write_checkpoint(1U) != RES_OK)
        {
            DL_TimerA_stopCounter(SMPL_CLK_INST);
            logger_state = LOGGER_STATE_ERROR;
            while (1) { __WFI(); }
        }
    }
    #endif
    printf("SAMPLING STOPPED; FINALIZING SD\n");
   
    // extra timer
    printf("sample_timing_gap_count = %lu\n", (unsigned long)sample_timing_gap_count);
    printf("sample_timing_max_interval_ticks = %lu\n", (unsigned long)sample_timing_max_interval_ticks);
    printf("sample_timing_first_gap_index = %lu\n", (unsigned long)sample_timing_first_gap_index);

    // intan start stop
    printf("intan_dma_frames_started = %lu\n", (unsigned long)intan_dma_frames_started);
    printf("intan_dma_frames_completed = %lu\n", (unsigned long)intan_dma_frames_completed);
    printf("intan_dma_frames_difference = %lu\n", (unsigned long)(intan_dma_frames_started - intan_dma_frames_completed));


    // SD MODE SWITCH: close stream only when SD ON
    #if SD_WRITES_ENABLED
    DRESULT stream_end_result = disk_stream_end(0U);
    if (stream_end_result != RES_OK)
    {
        printf("ERROR: could not end continuous SD write stream: %d\n", stream_end_result);
        logger_state = LOGGER_STATE_ERROR;
        while (1)
        {
            __WFI();
        }
    }
    #endif



    printf("buffer_overrun_count = %lu\n", (unsigned long)buffer_overrun_count);

    printf("timer_interrupts_skipped_intan_acquisition_because_previous_dma_still_busy = %lu\n",
           (unsigned long)timer_interrupts_skipped_intan_acquisition_because_previous_dma_still_busy);

    printf("FIRST SKIPPED DMA: tick=%lu time=%.6f s\n",
           (unsigned long)first_skipped_dma_tick,
           (double)first_skipped_dma_tick / 20000.0);
           
    uint32_t overruns_to_print = buffer_overrun_count;
    if (overruns_to_print > MAX_OVERRUN_EVENTS)
    {
        overruns_to_print = MAX_OVERRUN_EVENTS;
    }

    for (uint32_t i = 0U; i < overruns_to_print; i++)
    {
        printf("overrun[%lu] sample_index = %lu\n",
            (unsigned long)i,
            (unsigned long)overrun_sample_indices[i]);
    }

    printf("sd_writes_over_51_2ms = %lu\n", (unsigned long)sd_writes_over_51_2ms);

    uint32_t slow_writes_to_print = sd_writes_over_51_2ms;
       
    if (slow_writes_to_print > MAX_SLOW_WRITE_EVENTS)
    {
        slow_writes_to_print = MAX_SLOW_WRITE_EVENTS;
    }

    for (uint32_t i = 0U; i < slow_writes_to_print; i++)
    {
        printf("slow_write[%lu] start = %lu end = %lu\n",
            (unsigned long)i,
            (unsigned long)slow_write_start_indices[i],
            (unsigned long)slow_write_end_indices[i]);
    }

    printf("sd_write_max_ticks = %lu = %.2f ms\n",
        (unsigned long)sd_write_max_ticks,
        (double)sd_write_max_ticks * 0.05);



    logger_state = LOGGER_STATE_SYNCING;
    printf("RAW RECORDING STOPPED: %lu neural sectors written\n",
           (unsigned long)raw_sectors_written);
    DL_GPIO_setPins(GPIOA, RECORD__START_LED_RECORD_START_LED_PIN_PIN);
    DL_GPIO_clearPins(GPIOA, RECORD__START_LED_RECORD_START_LED_PIN_PIN);
    delay_cycles(CPUCLK_FREQ / 10U);
    DL_GPIO_setPins(GPIOA, RECORD__START_LED_RECORD_START_LED_PIN_PIN);

    acquisition_stopped = 0U;
    stop_requested = 0U;

    logger_state = LOGGER_STATE_STOPPED;


    /* Wait until the stop button is physically released. */
    while ((DL_GPIO_readPins(
                RECORD_BUTTON_PORT,
                RECORD_BUTTON_RECORD_BUTTON_PIN_PIN) &
            RECORD_BUTTON_RECORD_BUTTON_PIN_PIN) == 0U)
    {
    }

    /* Ignore button bounce for 250 ms after release. */
    delay_cycles(CPUCLK_FREQ / 4U);

    /* Require a new button press to start another recording. */
    button_press_latched = 0U;
    logger_state = LOGGER_STATE_SD_MOUNTED;
        
    }

    if (button_press_latched == 1U)
    {
        if ((DL_GPIO_readPins(RECORD_BUTTON_PORT, RECORD_BUTTON_RECORD_BUTTON_PIN_PIN) & RECORD_BUTTON_RECORD_BUTTON_PIN_PIN) != 0U)
        {
            delay_cycles(CPUCLK_FREQ / 50U); /* 20 ms */
            if ((DL_GPIO_readPins(RECORD_BUTTON_PORT, RECORD_BUTTON_RECORD_BUTTON_PIN_PIN) &
                RECORD_BUTTON_RECORD_BUTTON_PIN_PIN) != 0U)
            {
                button_press_latched = 0U;
            }
        }
    }
    else
    {
        __WFI();
    }
}
}
