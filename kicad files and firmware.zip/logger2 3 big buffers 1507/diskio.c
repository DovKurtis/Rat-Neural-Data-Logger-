#include "ff.h"
#include "diskio.h"
#include "ti_msp_dl_config.h"

#define SD_SPI SPI_1_USD_INST
/* 1U = sleep during SD write DMA; 0U = original polling. */
#define SD_DMA_SLEEP_ENABLED 0U
#define CS_LOW()        DL_GPIO_clearPins(SD_CS_PORT, SD_CS_SD_CS_PIN_PIN)
#define CS_HIGH()       DL_GPIO_setPins(SD_CS_PORT, SD_CS_SD_CS_PIN_PIN)

#include <stdio.h>

volatile uint8_t sd_fail_stage = 0U;
volatile uint8_t sd_fail_resp = 0U;
volatile UINT sd_fail_t = 0U;
volatile LBA_t sd_fail_sector = 0U;
volatile uint8_t sd_fail_cmd24_res = 0U;

static volatile DSTATUS Stat = STA_NOINIT;
static uint8_t BlockAddressing = 0;

static uint8_t sd_stream_active = 0U;
static LBA_t sd_stream_sector = 0U;

//poci low on 
extern volatile uint32_t sample_tick_count;
volatile uint32_t sd_busy_event_count = 0U;
volatile uint32_t sd_busy_start_ticks[4] = {0U};
volatile uint32_t sd_busy_end_ticks[4] = {0U};
volatile uint32_t sd_busy_sectors[4] = {0U};
#define SD_BUSY_LOG_THRESHOLD_TICKS 200U  /* 10 ms */
// poci low on 

static uint8_t spi_txrx(uint8_t b)
{
    while (DL_SPI_isBusy(SD_SPI)) {}
    DL_SPI_transmitData8(SD_SPI, b);
    while (DL_SPI_isRXFIFOEmpty(SD_SPI)) {}
    return DL_SPI_receiveData8(SD_SPI);
}

static void spi_tx(uint8_t b) { (void)spi_txrx(b); }
static uint8_t spi_rx(void) { return spi_txrx(0xFF); }

static void deselect(void)
{
    CS_HIGH();
    spi_rx();
}


static volatile uint8_t sd_rx_discard; /* Holds unwanted bytes received while transmitting an SD block. */

static uint8_t sd_tx_dummy = 0xFFU;

static void sd_dma_write_block(const uint8_t *buff)
{
    while (!DL_SPI_isRXFIFOEmpty(SD_SPI)) /* Remove any stale received bytes before starting DMA. */
    {
        (void)DL_SPI_receiveData8(SD_SPI);
    }
    DL_DMA_disableChannel(DMA, USD_RX_DMA_CH3_CHAN_ID); /* Stop SD RX DMA while reloading it. */
    DL_DMA_disableChannel(DMA, USD_TX_DMA_CH2_CHAN_ID); /* Stop SD TX DMA while reloading it. */
    DL_DMA_setSrcIncrement(DMA, USD_RX_DMA_CH3_CHAN_ID, DL_DMA_ADDR_UNCHANGED);

    DL_DMA_setDestIncrement(DMA, USD_RX_DMA_CH3_CHAN_ID, DL_DMA_ADDR_UNCHANGED);

    DL_DMA_setSrcIncrement(DMA, USD_TX_DMA_CH2_CHAN_ID, DL_DMA_ADDR_INCREMENT);
    DL_DMA_setDestIncrement(DMA, USD_TX_DMA_CH2_CHAN_ID, DL_DMA_ADDR_UNCHANGED);

    DL_DMA_setSrcAddr(DMA, USD_RX_DMA_CH3_CHAN_ID, (uint32_t)&SD_SPI->RXDATA); /* Read each simultaneous SPI RX byte. */
    DL_DMA_setDestAddr(DMA, USD_RX_DMA_CH3_CHAN_ID, (uint32_t)&sd_rx_discard); /* Discard those unwanted RX bytes. */
    DL_DMA_setTransferSize(DMA, USD_RX_DMA_CH3_CHAN_ID, 512U); /* Drain 512 received bytes. */
    DL_DMA_setSrcAddr(DMA, USD_TX_DMA_CH2_CHAN_ID, (uint32_t)buff); /* Read the 512-byte sector from RAM. */
    DL_DMA_setDestAddr(DMA, USD_TX_DMA_CH2_CHAN_ID, (uint32_t)&SD_SPI->TXDATA); /* Send bytes through SD SPI. */
    DL_DMA_setTransferSize(DMA, USD_TX_DMA_CH2_CHAN_ID, 512U); /* Send exactly one SD sector. */
    // DL_DMA_enableChannel(DMA, USD_RX_DMA_CH3_CHAN_ID); /* Start RX draining before transmission begins. */
    // DL_DMA_enableChannel(DMA, USD_TX_DMA_CH2_CHAN_ID); /* Start RAM-to-SD SPI transmission. */
    #if SD_DMA_SLEEP_ENABLED
        /* RX completion means all 512 transmitted bytes were received. */
        DL_DMA_clearInterruptStatus(DMA, DL_DMA_INTERRUPT_CHANNEL3);
        DL_DMA_enableInterrupt(DMA, DL_DMA_INTERRUPT_CHANNEL3);
        NVIC_EnableIRQ(DMA_INT_IRQn);
    #endif

        DL_DMA_enableChannel(DMA, USD_RX_DMA_CH3_CHAN_ID); /* Start RX draining before transmission begins. */
        DL_DMA_enableChannel(DMA, USD_TX_DMA_CH2_CHAN_ID); /* Start RAM-to-SD SPI transmission. */
    

    #if SD_DMA_SLEEP_ENABLED
        /* Sleep only from main code with interrupts initially enabled. */
        if ((__get_IPSR() == 0U) && (__get_PRIMASK() == 0U))
        {
            for (;;)
            {
                /* Prevent completion from being handled between
                * checking DMA and executing WFI.
                */
                __disable_irq();

                if (!DL_DMA_isChannelEnabled(DMA, USD_TX_DMA_CH2_CHAN_ID) &&
                    !DL_DMA_isChannelEnabled(DMA, USD_RX_DMA_CH3_CHAN_ID))
                {
                    __enable_irq();
                    break;
                }

                /* An enabled pending interrupt wakes WFI even while
                * PRIMASK defers executing its handler.
                */
                __DSB();
                __WFI();
                __enable_irq();
                __ISB();
            }
        }
        else
    #endif
        {
            while (DL_DMA_isChannelEnabled(DMA, USD_TX_DMA_CH2_CHAN_ID)) {}
            while (DL_DMA_isChannelEnabled(DMA, USD_RX_DMA_CH3_CHAN_ID)) {}
        }

        
    while (DL_SPI_isBusy(SD_SPI)) {} /* Wait until the final byte physically leaves SPI. */
}




//  ┌──────────────┬─────────────────────────────────────────────┬──────────────┐
//  │ Byte 0 (1B)  │               Bytes 1-4 (4B)                │  Byte 5 (1B) │
//  ├──────────────┼─────────────────────────────────────────────┼──────────────┤
//  │ Command Index│                  Argument                   │  CRC + Stop  │
//  │  0x40 + CMD  │  (e.g., Memory Address or Configuration)    │   7-bit Check│
//  └──────────────┴─────────────────────────────────────────────┴──────────────┘

static void sd_dma_read_block(uint8_t *buff)
{
    while (!DL_SPI_isRXFIFOEmpty(SD_SPI))
    {
        (void)DL_SPI_receiveData8(SD_SPI);
    }

    DL_DMA_disableChannel(DMA, USD_RX_DMA_CH3_CHAN_ID);
    DL_DMA_disableChannel(DMA, USD_TX_DMA_CH2_CHAN_ID);

    /* RX: SPI -> sequential RAM buffer. */
    DL_DMA_setSrcIncrement(
        DMA,
        USD_RX_DMA_CH3_CHAN_ID,
        DL_DMA_ADDR_UNCHANGED
    );

    DL_DMA_setDestIncrement(
        DMA,
        USD_RX_DMA_CH3_CHAN_ID,
        DL_DMA_ADDR_INCREMENT
    );

    DL_DMA_setSrcAddr(
        DMA,
        USD_RX_DMA_CH3_CHAN_ID,
        (uint32_t)&SD_SPI->RXDATA
    );

    DL_DMA_setDestAddr(
        DMA,
        USD_RX_DMA_CH3_CHAN_ID,
        (uint32_t)buff
    );

    DL_DMA_setTransferSize(
        DMA,
        USD_RX_DMA_CH3_CHAN_ID,
        512U
    );

    /* TX: repeatedly send 0xFF so SPI generates clocks for the read. */
    DL_DMA_setSrcIncrement(
        DMA,
        USD_TX_DMA_CH2_CHAN_ID,
        DL_DMA_ADDR_UNCHANGED
    );

    DL_DMA_setDestIncrement(
        DMA,
        USD_TX_DMA_CH2_CHAN_ID,
        DL_DMA_ADDR_UNCHANGED
    );

    DL_DMA_setSrcAddr(
        DMA,
        USD_TX_DMA_CH2_CHAN_ID,
        (uint32_t)&sd_tx_dummy
    );

    DL_DMA_setDestAddr(
        DMA,
        USD_TX_DMA_CH2_CHAN_ID,
        (uint32_t)&SD_SPI->TXDATA
    );

    DL_DMA_setTransferSize(
        DMA,
        USD_TX_DMA_CH2_CHAN_ID,
        512U
    );

    DL_DMA_enableChannel(DMA, USD_RX_DMA_CH3_CHAN_ID);
    DL_DMA_enableChannel(DMA, USD_TX_DMA_CH2_CHAN_ID);

    while (DL_DMA_isChannelEnabled(DMA, USD_TX_DMA_CH2_CHAN_ID)) {}
    while (DL_DMA_isChannelEnabled(DMA, USD_RX_DMA_CH3_CHAN_ID)) {}
    while (DL_SPI_isBusy(SD_SPI)) {}
}


static int select(void)
{
    CS_LOW();
    spi_rx();
    return 1;
}

static uint8_t send_cmd(uint8_t cmd, uint32_t arg)
{
    uint8_t n, res;

    if (cmd & 0x80) {
        cmd &= 0x7F;
        res = send_cmd(55, 0);
        if (res > 1) return res;
    }

    deselect();
    if (!select()) return 0xFF;

    spi_tx(0x40 | cmd);
    spi_tx((uint8_t)(arg >> 24));
    spi_tx((uint8_t)(arg >> 16));
    spi_tx((uint8_t)(arg >> 8));
    spi_tx((uint8_t)arg);
    n = 0x01;
    if (cmd == 0) n = 0x95;
    if (cmd == 8) n = 0x87;
    spi_tx(n);

    n = 10;
    do {
        res = spi_rx();
    } while ((res & 0x80) && --n);
    // printf("CMD %u -> RES %u\n", cmd, res);
    return res;
}

DSTATUS disk_status(BYTE pdrv)
{
    if (pdrv) return STA_NOINIT;
    return Stat;
}

DSTATUS disk_initialize(BYTE pdrv)
{
    uint8_t n, cmd, ocr[4];
    uint8_t res;
    UINT t;
    UINT attempts;

    printf("\n========== SD INITIALIZE ==========\n");

    if (pdrv)
    {
        printf("FAIL: pdrv = %u, expected 0\n", (unsigned)pdrv);
        return STA_NOINIT;
    }

    /*
     * SD power-up/startup clocks.
     */
    CS_HIGH();

    printf("\nSTEP 1: 80 STARTUP CLOCKS\n");
    printf("COMMUNICATION: MSPM0G3507 SPI1 <-> microSD\n");
    printf("SCLK: PB9 | MOSI: PB8 | MISO: PB7 | CS: PA27\n");
    printf("CS HIGH: SD card deselected\n");

    for (n = 10U; n != 0U; n--)
    {
        uint8_t startup_rx = spi_rx();

        printf(
            "TRANSFER %u: MCU PB8 (MOSI) TX=0xFF | "
            "SD PB7 (MISO) RX=0x%02X | "
            "8 clocks on PB9\n",
            (unsigned)(11U - n),
            (unsigned)startup_rx
        );
    }

    Stat = STA_NOINIT;
    BlockAddressing = 0U;

    printf("\nSTEP 2: CMD0 GO_IDLE_STATE\n");
    printf("MCU PA27 (CS) LOW: selecting microSD\n");
    printf("MCU PB8 (MOSI) -> SD: 40 00 00 00 00 95\n");
    printf("SD -> MCU PB7 (MISO): awaiting R1 response\n");

    // res = send_cmd(0U, 0U); old before spamming it 
    #define CMD0_MAX_ATTEMPTS 200U 
    uint32_t cmd0_attempts = 0U; 
    res = 0xFFU; 
    do 
    { 
        cmd0_attempts++;
        res = send_cmd(0U, 0U); 
    }
    while ((res != 0x01U) && (cmd0_attempts < CMD0_MAX_ATTEMPTS));

    printf("SD PB7 -> MCU SPI1: CMD0 R1 = 0x%02X\n",
           (unsigned)res);

    if (res != 0x01U)
    {
        printf(
            "FAIL: microSD R1 expected 0x01, received 0x%02X\n",
            (unsigned)res
        );
        printf("Check Saleae: PB9 clock, PB8 MOSI, PB7 MISO, PA27 CS\n");

        deselect();
        printf("========== SD INIT FAILED ==========\n\n");
        return Stat;
    }

    printf("  CMD0 PASS\n");

    /*
     * CMD8: SEND_IF_COND
     * Modern SD v2 card should return R1 = 0x01.
     */
    printf("\nSTEP 3: CMD8 SEND_IF_COND arg=0x000001AA\n");

    res = send_cmd(8U, 0x1AAU);

    printf("  CMD8 R1 = 0x%02X\n", (unsigned)res);

    if (res == 0x01U)
    {
        /*
         * SD v2 path.
         */
        printf("  CMD8 indicates SD v2-compatible response\n");

        for (n = 0U; n < 4U; n++)
        {
            ocr[n] = spi_rx();
        }

        printf(
            "  CMD8 trailing bytes = %02X %02X %02X %02X\n",
            (unsigned)ocr[0],
            (unsigned)ocr[1],
            (unsigned)ocr[2],
            (unsigned)ocr[3]
        );

        if ((ocr[2] != 0x01U) || (ocr[3] != 0xAAU))
        {
            printf(
                "FAIL AT CMD8 ECHO: expected final bytes 01 AA, got %02X %02X\n",
                (unsigned)ocr[2],
                (unsigned)ocr[3]
            );

            deselect();
            printf("========== SD INIT FAILED ==========\n\n");
            return Stat;
        }

        printf("  CMD8 voltage/check-pattern PASS\n");

        /*
         * ACMD41: initialize card.
         */
        printf("\nSTEP 4: ACMD41 HCS initialization loop\n");

        t = 10000U;
        attempts = 0U;
        res = 0xFFU;

        while (t-- != 0U)
        {
            attempts++;

            res = send_cmd(
                0x80U + 41U,
                1UL << 30
            );

            /*
             * Print early attempts, then periodic attempts,
             * and always print the success response.
             */
            if ((attempts <= 10U) ||
                ((attempts % 100U) == 0U) ||
                (res == 0x00U))
            {
                printf(
                    "  ACMD41 attempt %u: R1 = 0x%02X\n",
                    (unsigned)attempts,
                    (unsigned)res
                );
            }

            if (res == 0x00U)
            {
                break;
            }
        }

        if (res != 0x00U)
        {
            printf(
                "FAIL AT ACMD41: card never became ready after %u attempts; last R1=0x%02X\n",
                (unsigned)attempts,
                (unsigned)res
            );

            deselect();
            printf("========== SD INIT FAILED ==========\n\n");
            return Stat;
        }

        printf(
            "  ACMD41 PASS after %u attempts\n",
            (unsigned)attempts
        );

        /*
         * CMD58: READ_OCR
         */
        printf("\nSTEP 5: CMD58 READ_OCR\n");

        res = send_cmd(58U, 0U);

        printf("  CMD58 R1 = 0x%02X\n", (unsigned)res);

        if (res != 0x00U)
        {
            printf(
                "FAIL AT CMD58: expected R1=0x00, received 0x%02X\n",
                (unsigned)res
            );

            deselect();
            printf("========== SD INIT FAILED ==========\n\n");
            return Stat;
        }

        for (n = 0U; n < 4U; n++)
        {
            ocr[n] = spi_rx();
        }

        printf(
            "  OCR = %02X %02X %02X %02X\n",
            (unsigned)ocr[0],
            (unsigned)ocr[1],
            (unsigned)ocr[2],
            (unsigned)ocr[3]
        );

        BlockAddressing =
            ((ocr[0] & 0x40U) != 0U) ? 1U : 0U;

        printf(
            "  CCS bit = %u -> BlockAddressing = %u\n",
            (unsigned)((ocr[0] >> 6) & 1U),
            (unsigned)BlockAddressing
        );

        /*
         * SDHC/SDXC uses block addressing and does not need CMD16.
         * SDSC requires CMD16 to establish 512-byte blocks.
         */
        if (BlockAddressing != 0U)
        {
            printf("STEP 6: CMD16 skipped because card uses block addressing\n");
            Stat = 0U;
        }
        else
        {
            printf("\nSTEP 6: CMD16 SET_BLOCKLEN = 512\n");

            res = send_cmd(16U, 512U);

            printf("  CMD16 R1 = 0x%02X\n", (unsigned)res);

            if (res != 0x00U)
            {
                printf(
                    "FAIL AT CMD16: expected R1=0x00, received 0x%02X\n",
                    (unsigned)res
                );

                deselect();
                printf("========== SD INIT FAILED ==========\n\n");
                return Stat;
            }

            printf("  CMD16 PASS\n");
            Stat = 0U;
        }
    }
    else
    {
        /*
         * Legacy SD v1 / MMC path.
         */
        printf(
            "  CMD8 did not return 0x01; entering legacy-card path\n"
        );

        printf("\nSTEP 4 LEGACY: probe ACMD41\n");

        res = send_cmd(0x80U + 41U, 0U);

        printf(
            "  initial ACMD41 R1 = 0x%02X\n",
            (unsigned)res
        );

        cmd = (res <= 1U) ? (0x80U + 41U) : 1U;

        printf(
            "  selected initialization command = %s\n",
            (cmd == (0x80U + 41U)) ? "ACMD41" : "CMD1"
        );

        t = 10000U;
        attempts = 0U;
        res = 0xFFU;

        while (t-- != 0U)
        {
            attempts++;

            res = send_cmd(cmd, 0U);

            if ((attempts <= 10U) ||
                ((attempts % 100U) == 0U) ||
                (res == 0x00U))
            {
                printf(
                    "  legacy init attempt %u: R1 = 0x%02X\n",
                    (unsigned)attempts,
                    (unsigned)res
                );
            }

            if (res == 0x00U)
            {
                break;
            }
        }

        if (res != 0x00U)
        {
            printf(
                "FAIL LEGACY INIT: never became ready; last R1=0x%02X\n",
                (unsigned)res
            );

            deselect();
            printf("========== SD INIT FAILED ==========\n\n");
            return Stat;
        }

        printf("\nSTEP 5 LEGACY: CMD16 SET_BLOCKLEN = 512\n");

        res = send_cmd(16U, 512U);

        printf("  CMD16 R1 = 0x%02X\n", (unsigned)res);

        if (res != 0x00U)
        {
            printf(
                "FAIL AT LEGACY CMD16: R1=0x%02X\n",
                (unsigned)res
            );

            deselect();
            printf("========== SD INIT FAILED ==========\n\n");
            return Stat;
        }

        Stat = 0U;
    }

    deselect();

    if ((Stat & STA_NOINIT) == 0U)
    {
        printf("\nSTEP 7: initialization succeeded\n");
        printf("Switching SD SPI clock to high speed\n");

        DL_SPI_setBitRateSerialClockDivider(
            SD_SPI,
            1U
        );

        printf("========== SD INIT PASSED ==========\n\n");
    }
    else
    {
        printf("FAIL: reached end with STA_NOINIT still set\n");
        printf("========== SD INIT FAILED ==========\n\n");
    }

    return Stat;
}
// DSTATUS disk_initialize(BYTE pdrv)
// {
//     uint8_t n, cmd, ocr[4];
//     UINT t;

//     if (pdrv) return STA_NOINIT;

//     CS_HIGH();
//     for (n = 10; n; n--) spi_rx();

//     Stat = STA_NOINIT;
//     BlockAddressing = 0;

//     if (send_cmd(0, 0) == 1) {
//         if (send_cmd(8, 0x1AA) == 1) {
//             for (n = 0; n < 4; n++) ocr[n] = spi_rx();
//             if (ocr[2] == 0x01 && ocr[3] == 0xAA) {
//                 t = 10000;
//                 while (t-- && send_cmd(0x80 + 41, 1UL << 30)) {}
//                     if (t && send_cmd(58, 0) == 0) {
//                         for (n = 0; n < 4; n++) {
//                             ocr[n] = spi_rx();
//                         }

//                         BlockAddressing = (ocr[0] & 0x40U) ? 1U : 0U;

//                         if (BlockAddressing || send_cmd(16, 512) == 0) {
//                             Stat = 0;
//                         }
//                     }
//             }
//         } else {
//             cmd = (send_cmd(0x80 + 41, 0) <= 1) ? (0x80 + 41) : 1;
//             t = 10000;
//             while (t-- && send_cmd(cmd, 0)) {}
//             if (t && send_cmd(16, 512) == 0) Stat = 0;
//         }
//     }
//     deselect();
//     if ((Stat & STA_NOINIT) == 0U) /* Card initialization succeeded. */
//     {
//     DL_SPI_setBitRateSerialClockDivider(SD_SPI, 1U); /* 80 MHz / ((1 + 1) × 2) = 20 MHz SD clock. */
//     }
//     return Stat;
// }

DRESULT disk_read(BYTE pdrv, BYTE *buff, LBA_t sector, UINT count)
{
    if (pdrv || !count) return RES_PARERR;
    if (Stat & STA_NOINIT) return RES_NOTRDY;

    do {
        if (send_cmd(
                17,
                BlockAddressing
                    ? (uint32_t)sector
                    : ((uint32_t)sector * 512UL)
            ) != 0) {
            break;
        }
        UINT t = 40000;
        uint8_t token;
        do {
            token = spi_rx();
        } while (token == 0xFF && --t);
        if (token != 0xFE) break;
        sd_dma_read_block(buff);
        spi_rx();
        spi_rx();
        buff += 512;
        sector++;
    } while (--count);

    deselect();
    return count ? RES_ERROR : RES_OK;
}

#if FF_FS_READONLY == 0
DRESULT disk_write(BYTE pdrv, const BYTE *buff, LBA_t sector, UINT count)
{
    if (pdrv || !count) return RES_PARERR;
    if (Stat & STA_NOINIT) return RES_NOTRDY;


    
    if (count == 1U) // ONE SECTOR 
    {
        uint8_t cmd24_res = send_cmd(24U, BlockAddressing ? (uint32_t)sector : ((uint32_t)sector * 512UL));
        if (cmd24_res != 0U)
        {
            sd_fail_stage = 1U;
            sd_fail_cmd24_res = cmd24_res;
            sd_fail_sector = sector;
            deselect();
            return RES_ERROR;
        }

        spi_rx();
        spi_tx(0xFEU);                 /* Single-block data token. */
        sd_dma_write_block(buff);       /* Send exactly 512 bytes. */
        spi_tx(0xFFU);                  /* Dummy CRC byte 1. */
        spi_tx(0xFFU);                  /* Dummy CRC byte 2. */

        uint8_t resp = spi_rx();

        if ((resp & 0x1FU) != 0x05U)
        {
            sd_fail_stage = 2U;
            sd_fail_resp = resp;
            sd_fail_sector = sector;
            deselect();
            return RES_ERROR;
        }

        UINT t = 1000000U;



        while ((spi_rx() != 0xFFU) && (--t != 0U)) {}

        if (t == 0U)
        {
            sd_fail_stage = 3U;
            sd_fail_t = t;
            sd_fail_sector = sector;
            deselect();
            return RES_ERROR;
        }

        deselect();
        return RES_OK;
    }

    // MORE THAN ONE SECTOR 
    uint8_t acmd23_res = send_cmd(0x80U + 23U, (uint32_t)count);
    if (acmd23_res != 0U)
    {
        sd_fail_stage = 8U;
        sd_fail_resp = acmd23_res;
        sd_fail_sector = sector;
        deselect();
        return RES_ERROR;
    }
    uint8_t cmd25_res = send_cmd(25U, BlockAddressing ? (uint32_t)sector : ((uint32_t)sector * 512UL));
    if (cmd25_res != 0U)
    {
        sd_fail_stage = 4U;
        sd_fail_resp = cmd25_res;
        sd_fail_sector = sector;
        deselect();
        return RES_ERROR;
    }

    while (count > 0U)
    {
        spi_rx();
        spi_tx(0xFCU);                 /* Multi-block WRITE data token. */

        sd_dma_write_block(buff);       /* Send this 512-byte sector. */

        spi_tx(0xFFU);                  /* Dummy CRC byte 1. */
        spi_tx(0xFFU);                  /* Dummy CRC byte 2. */

        uint8_t resp = spi_rx();

        if ((resp & 0x1FU) != 0x05U)
        {
            sd_fail_stage = 5U;
            sd_fail_resp = resp;
            sd_fail_sector = sector;

            spi_tx(0xFDU);              /* Stop multi-block transmission. */
            deselect();
            return RES_ERROR;
        }

        /*
         * Card may internally program NAND flash here.
         * Wait until it releases busy before sending the next block.
         */
        UINT t = 1000000U;

        while ((spi_rx() != 0xFFU) && (--t != 0U)) {}

        DL_GPIO_clearPins(GPIOA, DL_GPIO_PIN_15);

        if (t == 0U)
        {
            sd_fail_stage = 6U;
            sd_fail_t = t;
            sd_fail_sector = sector;

            spi_tx(0xFDU);
            deselect();
            return RES_ERROR;
        }

        buff += 512U;
        sector++;
        count--;
    }

    /*
     * Tell the card that the CMD25 multi-block stream is finished.
     */
    spi_tx(0xFDU);

    /*
     * Wait for the card to finish processing the stop token.
     */
    UINT t = 1000000U;
    while ((spi_rx() != 0xFFU) && (--t != 0U)) {}
    if (t == 0U)
    {
        sd_fail_stage = 7U;
        sd_fail_t = t;
        sd_fail_sector = sector;
        deselect();
        return RES_ERROR;
    }

    deselect();
    return RES_OK;
}
#endif

// called ONCE per recording 
DRESULT disk_stream_begin(BYTE pdrv, LBA_t sector, UINT preerase_count)
{
    if (pdrv)
    {
        return RES_PARERR;
    }

    if (Stat & STA_NOINIT)
    {
        return RES_NOTRDY;
    }

    if (sd_stream_active == 1U)
    {
        return RES_ERROR;
    }

    uint8_t acmd23_res = send_cmd(0x80U + 23U, (uint32_t)preerase_count);
    if (acmd23_res != 0U)
    {
        sd_fail_stage = 12U;
        sd_fail_resp = acmd23_res;
        sd_fail_sector = sector;
        deselect();
        return RES_ERROR;
    }
    uint8_t cmd25_res = send_cmd(25U, BlockAddressing ? (uint32_t)sector : ((uint32_t)sector * 512UL));
    if (cmd25_res != 0U)
    {
        sd_fail_stage = 13U;
        sd_fail_resp = cmd25_res;
        sd_fail_sector = sector;
        deselect();
        return RES_ERROR;
    }

    sd_stream_sector = sector;
    sd_stream_active = 1U;

    return RES_OK;
}


DRESULT disk_stream_write(BYTE pdrv, const BYTE *buff, UINT count)
{
    if (pdrv || !count)
    {
        return RES_PARERR;
    }

    if ((Stat & STA_NOINIT) || (sd_stream_active == 0U))
    {
        return RES_NOTRDY;
    }

    while (count > 0U)
    {
        spi_rx();
        spi_tx(0xFCU); /* Send one multi-block WRITE data-start token. */

        sd_dma_write_block(buff); /* Send exactly one 512-byte sector. */

        spi_tx(0xFFU); /* Dummy CRC byte 1. */
        spi_tx(0xFFU); /* Dummy CRC byte 2. */

        uint8_t resp = spi_rx();

        if ((resp & 0x1FU) != 0x05U)
        {
            sd_fail_stage = 14U;
            sd_fail_resp = resp;
            sd_fail_sector = sd_stream_sector;

            spi_tx(0xFDU);
            deselect();
            sd_stream_active = 0U;

            return RES_ERROR;
        }

        //poci low off 
        // UINT t = 1000000U;
        // while ((spi_rx() != 0xFFU) && (--t != 0U)) {}
        //poci low off 

        //poci low on 
        UINT t = 1000000U;
        uint32_t busy_start = sample_tick_count;
        while ((spi_rx() != 0xFFU) && (--t != 0U)) {}
        uint32_t busy_end = sample_tick_count;
        if ((uint32_t)(busy_end - busy_start) >=
            SD_BUSY_LOG_THRESHOLD_TICKS)
        {
            uint32_t index = sd_busy_event_count & 3U;
            sd_busy_start_ticks[index] = busy_start;
            sd_busy_end_ticks[index] = busy_end;
            sd_busy_sectors[index] = (uint32_t)sd_stream_sector;
            sd_busy_event_count++;
        }
        //poci low on 

        if (t == 0U)
        {
            sd_fail_stage = 15U;
            sd_fail_t = t;
            sd_fail_sector = sd_stream_sector;

            spi_tx(0xFDU);
            deselect();
            sd_stream_active = 0U;

            return RES_ERROR;
        }

        buff += 512U;
        sd_stream_sector++;
        count--;
    }

    return RES_OK;
}

// called ONCE per recording 
DRESULT disk_stream_end(BYTE pdrv)
{
    if (pdrv)
    {
        return RES_PARERR;
    }

    if (sd_stream_active == 0U)
    {
        return RES_ERROR;
    }

    spi_tx(0xFDU); /* End the one continuous CMD25 write stream. */

    UINT t = 1000000U;


    while ((spi_rx() != 0xFFU) && (--t != 0U)) {}


    if (t == 0U)
    {
        sd_fail_stage = 16U;
        sd_fail_t = t;
        sd_fail_sector = sd_stream_sector;

        deselect();
        sd_stream_active = 0U;

        return RES_ERROR;
    }

    deselect();
    sd_stream_active = 0U;

    return RES_OK;
}

DRESULT disk_erase_range(BYTE pdrv, LBA_t start_sector, LBA_t end_sector)
{
    if (pdrv)
    {
        return RES_PARERR;
    }

    if (Stat & STA_NOINIT)
    {
        return RES_NOTRDY;
    }

    if (end_sector < start_sector)
    {
        return RES_PARERR;
    }

    uint32_t start_arg = BlockAddressing
        ? (uint32_t)start_sector
        : ((uint32_t)start_sector * 512UL);

    uint32_t end_arg = BlockAddressing
        ? (uint32_t)end_sector
        : ((uint32_t)end_sector * 512UL);

    uint8_t res = send_cmd(32U, start_arg);

    if (res != 0U)
    {
        sd_fail_stage = 9U;
        sd_fail_resp = res;
        sd_fail_sector = start_sector;
        deselect();
        return RES_ERROR;
    }

    res = send_cmd(33U, end_arg);

    if (res != 0U)
    {
        sd_fail_stage = 10U;
        sd_fail_resp = res;
        sd_fail_sector = end_sector;
        deselect();
        return RES_ERROR;
    }

    res = send_cmd(38U, 0U);

    if (res != 0U)
    {
        sd_fail_stage = 11U;
        sd_fail_resp = res;
        deselect();
        return RES_ERROR;
    }

    while (spi_rx() != 0xFFU)
    {
        /* Full-card erase may take a long time. Wait until the card releases busy. */
    }

    deselect();

    return RES_OK;
}

DRESULT disk_ioctl(BYTE pdrv, BYTE cmd, void *buff)
{
    if (pdrv)
    {
        return RES_PARERR;
    }

    if (Stat & STA_NOINIT)
    {
        return RES_NOTRDY;
    }

    switch (cmd)
    {
        case CTRL_SYNC:
            deselect();
            return RES_OK;

        case GET_SECTOR_SIZE:
            *(WORD *)buff = 512U;
            return RES_OK;

        case GET_BLOCK_SIZE:
            *(DWORD *)buff = 1U;
            return RES_OK;

        case GET_SECTOR_COUNT:
        {
            uint8_t csd[16];
            UINT t = 40000U;
            uint8_t token;

            if (send_cmd(9U, 0U) != 0U)
            {
                deselect();
                return RES_ERROR;
            }

            do
            {
                token = spi_rx();
            }
            while ((token == 0xFFU) && (--t != 0U));

            if (token != 0xFEU)
            {
                deselect();
                return RES_ERROR;
            }

            for (UINT i = 0U; i < 16U; i++)
            {
                csd[i] = spi_rx();
            }

            spi_rx();
            spi_rx();

            if ((csd[0] >> 6) == 1U)
            {
                uint32_t csize =
                    ((uint32_t)(csd[7] & 0x3FU) << 16) |
                    ((uint32_t)csd[8] << 8) |
                    (uint32_t)csd[9];

                *(LBA_t *)buff =
                    ((LBA_t)csize + 1U) * 1024U;
            }
            else
            {
                uint32_t read_bl_len =
                    (uint32_t)(csd[5] & 0x0FU);

                uint32_t csize =
                    ((uint32_t)(csd[6] & 0x03U) << 10) |
                    ((uint32_t)csd[7] << 2) |
                    ((uint32_t)(csd[8] & 0xC0U) >> 6);

                uint32_t csize_mult =
                    ((uint32_t)(csd[9] & 0x03U) << 1) |
                    ((uint32_t)(csd[10] & 0x80U) >> 7);

                uint64_t capacity_bytes =
                    ((uint64_t)csize + 1ULL) *
                    (1ULL << (csize_mult + 2U)) *
                    (1ULL << read_bl_len);

                *(LBA_t *)buff =
                    (LBA_t)(capacity_bytes / 512ULL);
            }

            deselect();
            return RES_OK;
        }

        default:
            return RES_PARERR;
    }
}




// /*-----------------------------------------------------------------------*/
// /* Low level disk I/O module SKELETON for FatFs     (C)ChaN, 2025        */
// /*-----------------------------------------------------------------------*/
// /* If a working storage control module is available, it should be        */
// /* attached to the FatFs via a glue function rather than modifying it.   */
// /* This is an example of glue functions to attach various exsisting      */
// /* storage control modules to the FatFs module with a defined API.       */
// /*-----------------------------------------------------------------------*/

// #include "ff.h"			/* Basic definitions of FatFs */
// #include "diskio.h"		/* Declarations FatFs MAI */

// /* Example: Declarations of the platform and disk functions in the project */
// #include "platform.h"
// #include "storage.h"

// /* Example: Mapping of physical drive number for each drive */
// #define DEV_FLASH	0	/* Map FTL to physical drive 0 */
// #define DEV_MMC		1	/* Map MMC/SD card to physical drive 1 */
// #define DEV_USB		2	/* Map USB MSD to physical drive 2 */


// /*-----------------------------------------------------------------------*/
// /* Get Drive Status                                                      */
// /*-----------------------------------------------------------------------*/

// DSTATUS disk_status (
// 	BYTE pdrv		/* Physical drive nmuber to identify the drive */
// )
// {
// 	DSTATUS stat;
// 	int result;

// 	switch (pdrv) {
// 	case DEV_RAM :
// 		result = RAM_disk_status();

// 		// translate the reslut code here

// 		return stat;

// 	case DEV_MMC :
// 		result = MMC_disk_status();

// 		// translate the reslut code here

// 		return stat;

// 	case DEV_USB :
// 		result = USB_disk_status();

// 		// translate the reslut code here

// 		return stat;
// 	}
// 	return STA_NOINIT;
// }



// /*-----------------------------------------------------------------------*/
// /* Inidialize a Drive                                                    */
// /*-----------------------------------------------------------------------*/

// DSTATUS disk_initialize (
// 	BYTE pdrv				/* Physical drive nmuber to identify the drive */
// )
// {
// 	DSTATUS stat;
// 	int result;

// 	switch (pdrv) {
// 	case DEV_RAM :
// 		result = RAM_disk_initialize();

// 		// translate the reslut code here

// 		return stat;

// 	case DEV_MMC :
// 		result = MMC_disk_initialize();

// 		// translate the reslut code here

// 		return stat;

// 	case DEV_USB :
// 		result = USB_disk_initialize();

// 		// translate the reslut code here

// 		return stat;
// 	}
// 	return STA_NOINIT;
// }



// /*-----------------------------------------------------------------------*/
// /* Read Sector(s)                                                        */
// /*-----------------------------------------------------------------------*/

// DRESULT disk_read (
// 	BYTE pdrv,		/* Physical drive nmuber to identify the drive */
// 	BYTE *buff,		/* Data buffer to store read data */
// 	LBA_t sector,	/* Start sector in LBA */
// 	UINT count		/* Number of sectors to read */
// )
// {
// 	DRESULT res;
// 	int result;

// 	switch (pdrv) {
// 	case DEV_RAM :
// 		// translate the arguments here

// 		result = RAM_disk_read(buff, sector, count);

// 		// translate the reslut code here

// 		return res;

// 	case DEV_MMC :
// 		// translate the arguments here

// 		result = MMC_disk_read(buff, sector, count);

// 		// translate the reslut code here

// 		return res;

// 	case DEV_USB :
// 		// translate the arguments here

// 		result = USB_disk_read(buff, sector, count);

// 		// translate the reslut code here

// 		return res;
// 	}

// 	return RES_PARERR;
// }



// /*-----------------------------------------------------------------------*/
// /* Write Sector(s)                                                       */
// /*-----------------------------------------------------------------------*/

// #if FF_FS_READONLY == 0

// DRESULT disk_write (
// 	BYTE pdrv,			/* Physical drive nmuber to identify the drive */
// 	const BYTE *buff,	/* Data to be written */
// 	LBA_t sector,		/* Start sector in LBA */
// 	UINT count			/* Number of sectors to write */
// )
// {
// 	DRESULT res;
// 	int result;

// 	switch (pdrv) {
// 	case DEV_RAM :
// 		// translate the arguments here

// 		result = RAM_disk_write(buff, sector, count);

// 		// translate the reslut code here

// 		return res;

// 	case DEV_MMC :
// 		// translate the arguments here

// 		result = MMC_disk_write(buff, sector, count);

// 		// translate the reslut code here

// 		return res;

// 	case DEV_USB :
// 		// translate the arguments here

// 		result = USB_disk_write(buff, sector, count);

// 		// translate the reslut code here

// 		return res;
// 	}

// 	return RES_PARERR;
// }

// #endif


// /*-----------------------------------------------------------------------*/
// /* Miscellaneous Functions                                               */
// /*-----------------------------------------------------------------------*/

// DRESULT disk_ioctl (
// 	BYTE pdrv,		/* Physical drive nmuber (0..) */
// 	BYTE cmd,		/* Control code */
// 	void *buff		/* Buffer to send/receive control data */
// )
// {
// 	DRESULT res;
// 	int result;

// 	switch (pdrv) {
// 	case DEV_RAM :

// 		// Process of the command for the RAM drive

// 		return res;

// 	case DEV_MMC :

// 		// Process of the command for the MMC/SD card

// 		return res;

// 	case DEV_USB :

// 		// Process of the command the USB drive

// 		return res;
// 	}

// 	return RES_PARERR;
// }

